(() => {
  'use strict';

  const descriptions = {
    conectividade: 'Ativação dos serviços conectados: Pareado + Pareado depois sobre o total de chassis.',
    ltsm: 'Checagem de bateria no estoque: On Time + Done Late sobre o total de chassis elegíveis.',
    battery_check: 'Saúde da bateria na preparação do veículo novo: OK sobre o total Network.',
    dda: 'Jornada do veículo: média dos resultados de Recepção, Preparação e Entrega.'
  };

  const processSoftColors = {
    conectividade: '#f5c9dc',
    ltsm: '#c9dfd7',
    battery_check: '#d9cbe8',
    dda: '#f3df8f'
  };

  const isGroupReport = document.body.dataset.mode === 'group-report';

  const state = {
    data: null,
    page: isGroupReport ? 'group-summary' : 'overview',
    model: '',
    ddaChassisModule: 'preparation',
    groupSummaryLevel: 'Grupo',
    groupSummaryKey: '',
    process: 'conectividade',
    period: '',
    periods: new Set(),
    snapshot: 'ultimo_dia',
    regions: new Set(),
    view: 'performance',
    entityLevel: isGroupReport ? 'Concessionária' : 'Grupo',
    selectedEntity: null,
    selectedMonths: new Set(),
    timelinePeriods: new Set(),
    timelineComponents: new Set(['result']),
    snapshotScope: isGroupReport ? 'Grupo' : 'Brasil',
    overviewPeriods: new Set(),
    overviewRegions: new Set(),
    chassisCache: new Map(),
    chassisManifest: null, chassisPending: new Map(), chassisRequest: 0
  };


  const $ = (id) => document.getElementById(id);
  const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const fmtPct = (value) => value == null || Number.isNaN(value) ? '–' : `${(value * 100).toLocaleString('pt-BR', {minimumFractionDigits:1, maximumFractionDigits:1})}%`;
  const fmtPp = (value) => value == null || Number.isNaN(value) ? '–' : `${value >= 0 ? '+' : ''}${(value * 100).toLocaleString('pt-BR', {minimumFractionDigits:1, maximumFractionDigits:1})} p.p.`;
  const fmtInt = (value) => value == null ? '–' : Number(value).toLocaleString('pt-BR');
  const fmtPeriod = (period) => { if (!period) return '–'; const [year, month] = period.split('-'); return `${month}/${year}`; };
  const fmtMonthShort = (period) => { if (!period) return '–'; const [year, month] = period.split('-'); return `${['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'][Number(month) - 1]}/${year}`; };
  const dataReferencePeriod = () => {
    const match = String(state.data?.generated_at || '').match(/^(\d{4})-(\d{2})/);
    return match ? `${match[1]}-${match[2]}` : '';
  };
  const isCurrentPeriod = (period) => Boolean(period && period === dataReferencePeriod());
  const snapshotLabel = (snapshot, period = state.period) => snapshot === 'ytd_atual' ? 'YTD mais atual' : isCurrentPeriod(period) ? 'Mês atual (parcial)' : snapshot === 'oficial' ? 'Fechamento oficial (D+15)' : snapshot === 'parcial' ? 'Parcial' : 'Último dia do mês';
  const snapshotShort = (snapshot, period = state.period) => snapshot === 'ytd_atual' ? 'YTD mais atual' : isCurrentPeriod(period) ? 'Mês atual (parcial)' : snapshot === 'oficial' ? 'Fechamento D+15' : snapshot === 'parcial' ? 'Parcial' : 'Último dia do mês';
  const bandLabel = (band) => ({good:'Enquadrado', bad:'Desenquadrado', attention:'Atenção', neutral:'Sem meta'})[band] || 'Sem meta';
  const processMeta = () => state.data.processes[state.process];
  const selectedRegions = (row) => !row.region || state.regions.has(row.region);

  // A mesma seleção de modelo é respeitada nas métricas pré-agregadas
  // (sem baixar chassis, inclusive no GitHub Pages).
  function normalizedModelName(value) {
    return String(value || '').trim().toUpperCase().replace(/\s+/g,' ').replace(/(?:\s*\(LATAM\)|\s+MERCOSUR)$/,'').trim();
  }
  function metricRows() {
    return state.model ? (state.data?.model_metrics || []).filter((row) => row.model === state.model) : (state.data?.metrics || []);
  }
  // GitHub Pages v1.5.8: resultados comuns em partes compactas. As métricas
  // de cada modelo só são buscadas quando esse modelo é selecionado.
  let metricManifest = null;
  const modelMetricCache = new Map();
  const modelMetricPending = new Map();
  let modelSelectionRequest = 0;

  function unpackMetricPart(packed) {
    const columns = packed.columns || [];
    const dictionaries = packed.dictionaries || {};
    return (packed.rows || []).map(values => {
      const row = {};
      columns.forEach((key, i) => {
        const value = values[i];
        if (value === '\u0000metric_missing\u0000') return;
        row[key] = Object.prototype.hasOwnProperty.call(dictionaries, key) && value != null
          ? dictionaries[key][value] : value;
      });
      return row;
    });
  }

  async function loadMetricDataset(entry) {
    if (!entry) return [];
    const parts = entry.parts || [];
    // Limita os pedidos simultâneos, útil para internet móvel.
    const results = new Array(parts.length);
    let next = 0;
    async function worker() {
      while (next < parts.length) {
        const idx = next++;
        const part = parts[idx];
        let response;
        try {
          response = await fetch(part.url);
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          const packed = await response.json();
          results[idx] = unpackMetricPart(packed);
          if (results[idx].length !== part.count) throw new Error('Contagem incorreta na parte');
        } catch (error) {
          console.error('Falha ao carregar métricas:', part.url, error);
          throw new Error(`Não foi possível carregar ${part.url}. Verifique os arquivos publicados.`);
        }
      }
    }
    await Promise.all(Array.from({length: Math.min(4, parts.length)}, () => worker()));
    const rows = results.flat();
    if (rows.length !== entry.count) throw new Error('Quantidade de métricas diferente do manifesto.');
    return rows;
  }

  async function loadPublishedMetrics() {
    const response = await fetch(state.data.metric_manifest || './data/metrics/manifest.json');
    if (!response.ok) throw new Error('Não foi possível carregar o manifesto de métricas.');
    metricManifest = await response.json();
    if (metricManifest.encoding !== 'table-v1') throw new Error('Formato de métricas não reconhecido.');
    const processes = Object.keys(state.data.processes || {});
    const groups = await Promise.all(processes.map(process => loadMetricDataset(metricManifest.base[process])));
    state.data.metrics = groups.flat();
    state.data.model_metrics = [];
  }

  async function ensureModelMetrics(model) {
    if (!model || document.body.dataset.mode !== 'github-pages' || !metricManifest) return;
    if (modelMetricCache.has(model)) {
      state.data.model_metrics = modelMetricCache.get(model);
      return;
    }
    if (!modelMetricPending.has(model)) {
      const task = loadMetricDataset(metricManifest.models[model]).then(rows => {
        modelMetricCache.set(model, rows);
        // Limitar memória a três modelos, mantendo cache dos mais recentes.
        while (modelMetricCache.size > 3) modelMetricCache.delete(modelMetricCache.keys().next().value);
        return rows;
      });
      modelMetricPending.set(model, task);
    }
    try {
      const rows = await modelMetricPending.get(model);
      if (state.model === model) state.data.model_metrics = rows;
    } finally {
      modelMetricPending.delete(model);
    }
  }

  function renderModelFilter() {
    const selector = $('globalModel');
    if (!selector || !state.data) return;
    const models = [...new Set(Object.values(state.data.models || {}).flat())].sort((a,b)=>a.localeCompare(b,'pt-BR'));
    selector.innerHTML = '<option value="">Todos os modelos</option>' + models.map((name) => `<option value="${esc(name)}">${esc(name)}</option>`).join('');
    if (!models.includes(state.model)) state.model = '';
    selector.value = state.model;
    $('globalModelNote').textContent = state.model ? `Filtrando somente ${state.model}, inclusive nos resumos e acumulados.` : 'Aplicado aos quatro processos e a todas as análises.';
  }

  const ytdProcesses = new Set(['conectividade', 'ltsm']);

  function processPeriods(process = state.process) {
    return state.data?.availability?.[process]?.periods || [];
  }

  function selectedProcessPeriods() {
    const available = processPeriods();
    return available.filter((period) => state.periods.has(period));
  }

  function selectionPeriodLabel(periods = selectedProcessPeriods()) {
    if (!periods.length) return 'Sem período';
    if (periods.length === 1) return fmtPeriod(periods[0]);
    if (periods.length === processPeriods().length) return `Todos · ${periods.length} meses`;
    return `${periods.length} meses`;
  }

  function effectiveSnapshots(process, period, includeYtd = false) {
    let snapshots = [...(state.data.availability[process]?.snapshots?.[period] || [])];
    if (process === 'conectividade') snapshots = snapshots.filter((snapshot) => snapshot !== 'oficial');
    if (!includeYtd || !ytdProcesses.has(process)) snapshots = snapshots.filter((snapshot) => snapshot !== 'ytd_atual');
    if (isCurrentPeriod(period)) {
      const monthly = snapshots.filter((snapshot) => snapshot !== 'oficial' && snapshot !== 'ytd_atual');
      const ytd = includeYtd && snapshots.includes('ytd_atual') ? ['ytd_atual'] : [];
      if (monthly.length) snapshots = [...monthly, ...ytd];
    }
    return [...new Set(snapshots)];
  }

  function preferredSnapshot(process, period, selected = null) {
    const snapshots = effectiveSnapshots(process, period, false);
    if (isCurrentPeriod(period) && snapshots.includes('parcial')) return 'parcial';
    if (selected && snapshots.includes(selected)) return selected;
    if (isCurrentPeriod(period) || process === 'conectividade') return snapshots.includes('ultimo_dia') ? 'ultimo_dia' : snapshots.includes('parcial') ? 'parcial' : snapshots[0];
    return snapshots.includes('oficial') ? 'oficial' : snapshots.includes('ultimo_dia') ? 'ultimo_dia' : snapshots.includes('parcial') ? 'parcial' : snapshots[0];
  }

  function snapshotForSelectionPeriod(period, selected = state.snapshot) {
    const available = state.data.availability[state.process]?.snapshots?.[period] || [];
    if (selected === 'ytd_atual' && ytdProcesses.has(state.process)) return 'ytd_atual';
    if (available.includes(selected)) return selected;
    if (selected === 'ultimo_dia' && isCurrentPeriod(period) && available.includes('parcial')) return 'parcial';
    if (selected === 'oficial' && !available.includes('oficial')) return preferredSnapshot(state.process, period);
    return preferredSnapshot(state.process, period, selected);
  }

  function latestSummaryRow(process) {
    const periods = state.data.availability[process]?.periods || [];
    const period = periods.at(-1);
    if (!period) return null;
    const snapshot = preferredSnapshot(process, period);
    return metricRows().find((row) => row.process === process && row.period === period && row.snapshot === snapshot && row.level === 'Brasil') || null;
  }

  function toast(message) {
    const element = $('toast');
    element.textContent = message;
    element.classList.add('show');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => element.classList.remove('show'), 2600);
  }

  function setProgress(show, percent = 0, stage = 'Preparando dashboard', message = '') {
    $('progressOverlay').classList.toggle('hidden', !show);
    $('progressBar').style.width = `${percent}%`;
    $('progressPercent').textContent = `${percent}%`;
    $('progressStage').textContent = stage;
    $('progressMessage').textContent = message || stage;
  }

  async function pollProgress(stopPromise) {
    const started = Date.now();
    let done = false;
    stopPromise.finally(() => { done = true; });
    while (!done) {
      try {
        const progress = await fetch('/api/progress').then((response) => response.json());
        setProgress(true, progress.percent || 0, progress.stage || 'Processando', progress.message || '');
        $('progressElapsed').textContent = `${Math.floor((Date.now() - started) / 1000)}s`;
      } catch (error) {}
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
  }

  async function loadData() {
    if (window.INLINE_PAYLOAD) {
      state.data = window.INLINE_PAYLOAD;
      setProgress(false);
      initialize();
      return;
    }
    if (document.body.dataset.mode === 'github-pages') {
      if (location.protocol === 'file:') throw new Error('Esta versão foi criada para publicação em GitHub Pages e precisa ser aberta por HTTP. Para uso local, utilize o HTML completo offline.');
      setProgress(true, 15, 'Preparando dashboard', 'Carregando dados agregados.');
      const response = await fetch('./data/dashboard.json');
      if (!response.ok) throw new Error('Não foi possível carregar dashboard.json.');
      state.data = await response.json();
      if (state.data.metric_storage_mode === 'sharded-v1') {
        setProgress(true, 48, 'Carregando métricas', 'Carregando resultados gerais; métricas de modelos serão baixadas sob demanda.');
        await loadPublishedMetrics();
      }
      setProgress(false);
      initialize();
      return;
    }
    setProgress(true, 0, 'Preparando dashboard', 'Lendo o estado do processamento.');
    const started = Date.now();
    while (true) {
      const progress = await fetch('/api/progress').then((response) => response.json());
      setProgress(true, progress.percent || 0, progress.stage || 'Preparando dashboard', progress.message || '');
      $('progressElapsed').textContent = `${Math.floor((Date.now() - started) / 1000)}s`;
      if (progress.status === 'done') break;
      if (progress.status === 'error') throw new Error(progress.message || 'Falha ao carregar as bases.');
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
    state.data = await fetch('/api/dashboard').then((response) => response.json());
    setProgress(false);
    initialize();
  }

  function initialize() {
    const available = Object.keys(state.data.availability).find((key) => state.data.availability[key].periods.length);
    if (!state.data.availability[state.process]?.periods.length && available) state.process = available;
    if (!state.regions.size) state.regions = new Set(state.data.regions);
    const overviewAvailablePeriods = [...new Set(Object.values(state.data.availability).flatMap((item) => item.periods || []))].sort();
    if (!state.overviewPeriods.size && overviewAvailablePeriods.length) state.overviewPeriods = new Set([overviewAvailablePeriods.includes(dataReferencePeriod()) ? dataReferencePeriod() : overviewAvailablePeriods.at(-1)]);
    if (!state.overviewRegions.size) state.overviewRegions = new Set(state.data.regions);
    $('generatedAt').textContent = new Date(state.data.generated_at).toLocaleString('pt-BR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'});
    $('footerVersion').textContent = `v${state.data.version}`;
    if (state.data.demo_mode) $('overviewDescription').textContent = 'Cenário completo com resultados artificiais para validar metas, filtros, rankings, linha do tempo, YTD e detalhamentos.';
    if (isGroupReport) {
      const scoped = state.data.group_report;
      if (!scoped || !scoped.group || !scoped.region) throw new Error('Relatório de grupo sem identificação válida.');
      state.groupSummaryKey = `${scoped.region}|${scoped.group}`;
      qsa('[data-toggle="entity"] button').forEach(button => button.classList.toggle('active', button.dataset.entity === 'Concessionária'));
      $('groupSummaryDescription').textContent = `${scoped.group} · ${scoped.region}`;
    }
    bindOnce();
    renderModelFilter();
    updateProcessControls();
    renderDiagnostics();
  }

  let bound = false;
  function bindOnce() {
    if (bound) return;
    bound = true;
    qsa('.process-tab').forEach((button) => button.addEventListener('click', () => {
      if (button.dataset.page === 'overview') showOverview();
      else if (button.dataset.page === 'group-summary') showGroupSummary();
      else switchProcess(button.dataset.process);
    }));
    qsa('.subtab').forEach((button) => button.addEventListener('click', () => activateView(button.dataset.view)));
    qsa('[data-toggle="entity"] button').forEach((button) => button.addEventListener('click', () => setEntityLevel(button.dataset.entity)));
    qsa('.copy-image').forEach((button) => button.addEventListener('click', () => copyBlockAsPng(button.dataset.copy)));
    ['rankingSearch','rankingSort','rankingOrder'].forEach((id) => $(id).addEventListener(id === 'rankingSearch' ? 'input' : 'change', renderRanking));
    $('timelineSort').addEventListener('change', renderTimeline);
    $('timelineOrder').addEventListener('change', renderTimeline);
    $('timelineSearch').addEventListener('input', renderTimeline);
    $('snapshotScopeSelect').addEventListener('change', (event) => {
      state.snapshotScope = event.target.value;
      renderSnapshotHistory();
    });
    $('entitySearch').addEventListener('input', renderSearch);
    $('globalModel')?.addEventListener('change', async (event) => {
      const request = ++modelSelectionRequest;
      const previous = state.model;
      state.model = event.target.value;
      state.chassisCache.clear();
      renderModelFilter();
      if (state.model && metricManifest) {
        const requested = state.model;
        $('globalModelNote').textContent = `Carregando resultados de ${requested}...`;
        try {
          await ensureModelMetrics(requested);
        } catch (error) {
          console.error('Erro no filtro de modelo:', error);
          if (request !== modelSelectionRequest) return;
          state.model = previous;
          renderModelFilter();
          toast('Não foi possível carregar as métricas do modelo. Tente novamente.');
          return;
        }
      }
      if (request !== modelSelectionRequest) return;
      renderModelFilter();
      renderOverview();
      renderGroupSummary();
      renderAll();
    });
    $('groupSummaryLevel').addEventListener('change', (event) => {
      state.groupSummaryLevel = event.target.value;
      state.groupSummaryKey = '';
      $('groupSummarySearch').value = '';
      renderGroupSummary();
    });
    $('groupSummarySearch').addEventListener('input', renderGroupSummary);
    $('groupSummaryEntity').addEventListener('change', (event) => {
      state.groupSummaryKey = event.target.value;
      renderGroupSummary();
    });
    qsa('[data-dda-module]').forEach((button) => button.addEventListener('click', () => {
      state.ddaChassisModule = button.dataset.ddaModule;
      qsa('[data-dda-module]').forEach((item) => item.classList.toggle('active', item === button));
      renderChassis();
    }));
    ['chassisStatus','chassisDateFrom','chassisDateTo','chassisRegion'].forEach((id) => $(id).addEventListener('change', renderChassis));
    ['chassisGroup','chassisDealer','chassisVin'].forEach((id) => $(id).addEventListener('input', renderChassis));
    $('clearChassisFilters').addEventListener('click', clearChassisFilters);
    $('refreshView').addEventListener('click', () => { renderAll(); toast('Visão atualizada.'); });
    $('reloadBases')?.addEventListener('click', reloadBases);
    $('exportFull')?.addEventListener('click', () => exportHtml('full'));
    $('exportPhone')?.addEventListener('click', () => exportHtml('iphone'));
    $('exportGithub')?.addEventListener('click', () => exportHtml('github-pages'));
    $('exportGroups')?.addEventListener('click', () => exportHtml('groups'));
    $('openDiagnostics').addEventListener('click', openDiagnostics);
    $('closeDiagnostics').addEventListener('click', () => $('diagnosticsDialog').close());
    $('diagnosticsDialog').addEventListener('click', (event) => {
      if (event.target === $('diagnosticsDialog')) $('diagnosticsDialog').close();
    });
  }

  function switchProcess(process) {
    $('overviewTooltip').hidden = true;
    if (!process) return;
    if (process === state.process && state.page === 'process') return;
    state.page = 'process';
    state.process = process;
    state.snapshot = '';
    state.periods.clear();
    state.selectedEntity = null;
    state.selectedMonths.clear();
    state.timelinePeriods.clear();
    state.timelineComponents = new Set(['result']);
    state.snapshotScope = 'Brasil';
    $('entitySearch').value = '';
    $('timelineSearch').value = '';
    $('rankingSearch').value = '';
    clearChassisFilters(false);
    syncMainSection();
    updateProcessControls();
  }

  function showOverview() {
    state.page = 'overview';
    syncMainSection();
    renderOverview();
  }

  function showGroupSummary() {
    state.page = 'group-summary';
    syncMainSection();
    renderGroupSummary();
  }

  function syncMainSection() {
    const isOverview = state.page === 'overview';
    const isGroup = state.page === 'group-summary';
    $('processOverview').hidden = !isOverview;
    $('groupSummaryWorkspace').hidden = !isGroup;
    $('processWorkspace').hidden = isOverview || isGroup;
    qsa('.process-tab').forEach((button) => {
      const active = isOverview ? button.dataset.page === 'overview' : isGroup ? button.dataset.page === 'group-summary' : button.dataset.process === state.process;
      button.classList.toggle('active', active);
    });
  }

  function activateView(view) {
    state.view = view;
    qsa('.subtab').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
    qsa('.view-panel').forEach((panel) => panel.classList.toggle('active', panel.id === view));
    $('regionFilterGroup').hidden = view === 'search' || view === 'snapshots' || view === 'chassis';
    $('snapshotFilterGroup').hidden = view === 'snapshots';
    updateSnapshotToggle();
    if (view === 'snapshots') renderSnapshotHistory();
    if (view === 'ranking') renderRanking();
    if (view === 'timeline') renderTimeline();
    if (view === 'topflop') renderTopFlop();
    if (view === 'search') renderSearch();
    if (view === 'chassis') renderChassis();
  }

  function setEntityLevel(level) {
    if (level === state.entityLevel) return;
    state.entityLevel = level;
    state.selectedEntity = null;
    state.selectedMonths.clear();
    $('entitySearch').value = '';
    qsa('[data-toggle="entity"] button').forEach((button) => button.classList.toggle('active', button.dataset.entity === level));
    renderTimeline();
    renderRanking();
    renderTopFlop();
    renderSearch();
    renderChassis();
  }

  function updateProcessControls() {
    const meta = processMeta();
    document.documentElement.style.setProperty('--process', meta.color);
    document.documentElement.style.setProperty('--process-soft', processSoftColors[state.process] || '#e5e5e5');
    const tint = weight => {const hex=meta.color.replace('#','');return 'rgb('+[0,2,4].map(i=>Math.round(parseInt(hex.slice(i,i+2),16)*weight+255*(1-weight))).join(',')+')';};
    document.documentElement.style.setProperty('--process-tint',tint(.10));
    document.documentElement.style.setProperty('--process-hover-tint',tint(.17));
    syncMainSection();
    $('processTitle').textContent = meta.name;
    $('processTitle').title = descriptions[state.process] || '';
    $('processGoal').textContent = meta.target == null ? 'Sem meta definida' : `Objetivo ${fmtPct(meta.target)}`;
    const periods = processPeriods();
    state.periods = new Set([...state.periods].filter((period) => periods.includes(period)));
    if (!state.periods.size && periods.length) state.periods.add(periods.includes(dataReferencePeriod()) ? dataReferencePeriod() : periods.at(-1));
    state.period = selectedProcessPeriods().at(-1) || periods.at(-1) || '';
    state.timelinePeriods = new Set(selectedProcessPeriods());
    renderPeriodControl();
    updateSnapshotToggle();
    renderRegionChips();
    renderSnapshotScopeControl();
    renderTimelineControls();
    renderOverview();
    renderGroupSummary();
    renderAll();
  }

  function applyPeriodSelection(next) {
    const available = processPeriods();
    state.periods = new Set([...next].filter((period) => available.includes(period)));
    if (!state.periods.size && available.length) state.periods.add(available.at(-1));
    state.period = selectedProcessPeriods().at(-1) || '';
    if (state.snapshot !== 'ytd_atual') state.snapshot = snapshotForSelectionPeriod(state.period, state.snapshot) || preferredSnapshot(state.process, state.period) || 'ultimo_dia';
    state.timelinePeriods = new Set(selectedProcessPeriods());
    state.selectedEntity = null;
    renderPeriodControl();
    updateSnapshotToggle();
    renderTimelineControls();
    renderAll();
  }

  function renderPeriodControl() {
    const periods = processPeriods();
    const selected = selectedProcessPeriods();
    const summary = $('periodSelectorSummary');
    if (!summary || !$('periodOptions')) return;
    summary.textContent = selected.length === 1 ? fmtPeriod(selected[0]) : selected.length === periods.length && periods.length > 1 ? `Todos · ${selected.length} meses` : `${selected.length} meses`;
    summary.title = selected.map(fmtPeriod).join(', ');
    $('periodOptions').innerHTML = periods.slice().reverse().map((period) => `<button type="button" class="period-option ${state.periods.has(period) ? 'active' : ''}" data-period-option="${period}">${fmtPeriod(period)}</button>`).join('') || '<span class="muted">Sem dados</span>';
    qsa('[data-period-option]', $('periodOptions')).forEach((button) => button.addEventListener('click', () => {
      const next = new Set(state.periods);
      const period = button.dataset.periodOption;
      if (next.has(period)) {
        if (next.size === 1) return toast('Mantenha ao menos um mês selecionado.');
        next.delete(period);
      } else next.add(period);
      applyPeriodSelection(next);
    }));
    qsa('[data-period-action]', $('periodSelector')).forEach((button) => button.onclick = () => {
      applyPeriodSelection(button.dataset.periodAction === 'all' ? new Set(periods) : new Set(periods.length ? [periods.at(-1)] : []));
    });
  }

  function firstComponentCount(row, keys) {
    for (const key of keys) {
      if (Object.prototype.hasOwnProperty.call(row.components || {}, key)) return Number(row.components[key] || 0);
    }
    return 0;
  }

  function overviewComponentMarkup(process, row, meta) {
    if (process === 'dda') {
      const labels = {reception:'Recepção', preparation:'Preparação', delivery:'Entrega'};
      return Object.entries(labels).map(([key, label]) => {
        const component = row.components?.[key] || {};
        return `<div><span>${label}</span><strong class="metric ${component.band || 'neutral'}">${fmtPct(component.metric)}</strong></div>`;
      }).join('');
    }
    if (process === 'conectividade') {
      const paired = firstComponentCount(row, ['Pareado', 'Conectado', 'Success']);
      const later = firstComponentCount(row, ['Pareado depois', 'Conectado depois', 'Paired later']);
      const notPaired = firstComponentCount(row, ['Não pareado', 'Não conectado']);
      const items = [
        ['Pareado', paired, 'paired'],
        ['Pareado depois', later, 'paired_later'],
        ['Total Pareado', paired + later, 'result'],
        ['Não pareado', notPaired, 'not_paired']
      ];
      return items.map(([label, count, key]) => `<div><span>${label}</span><strong class="metric ${componentBand(row, key, process)}">${fmtPct(row.denominator ? count / row.denominator : null)}</strong></div>`).join('');
    }
    return meta.statuses.map((status) => {
      const count = row.components?.[status] || 0;
      const share = row.denominator ? count / row.denominator : null;
      const key = process === 'battery_check' ? (status === 'OK' ? 'result' : 'ko') : status;
      return `<div><span>${esc(status)}</span><strong class="metric ${componentBand(row, key, process)}">${fmtPct(share)}</strong></div>`;
    }).join('');
  }

  function awaitsOfficial(process, period) {
    const snapshots = effectiveSnapshots(process,period);
    return process !== 'conectividade' && !isCurrentPeriod(period) && snapshots.includes('ultimo_dia') && !snapshots.includes('oficial');
  }
  function provisionalRow(row) { return row ? {...row, provisional:true} : null; }

  function rankingAnnualRows() {
    const year = state.period.slice(0,4);
    const monthly = metricRows().filter(row => row.process === state.process && row.level === state.entityLevel && row.period.startsWith(year + '-') && /^\d{4}-\d{2}$/.test(row.period) && row.period <= state.period);
    if (['conectividade', 'ltsm'].includes(state.process)) return monthly.filter(row => row.snapshot === 'ytd_atual');
    return monthly.filter(row => row.snapshot === preferredSnapshot(state.process,row.period));
  }
  function renderRanking() {
    if (!state.data) return;
    const periodsSelected = selectedProcessPeriods();
    const monthRows = activeRows(state.entityLevel).filter(selectedRegions);
    const annualRows = rankingAnnualRows().filter(selectedRegions);
    const selectedBuckets = new Map();
    monthRows.forEach((row) => {
      const key = entityKey(row);
      if (!selectedBuckets.has(key)) selectedBuckets.set(key, []);
      selectedBuckets.get(key).push(row);
    });
    const annualBuckets = new Map();
    annualRows.forEach((row) => {
      const key = entityKey(row);
      if (!annualBuckets.has(key)) annualBuckets.set(key, []);
      annualBuckets.get(key).push(row);
    });
    const rankingScopeVolume = [...selectedBuckets.values()].reduce((total, rows) => total + (combine(rows)?.denominator || 0), 0);
    const keys = new Set([...selectedBuckets.keys(), ...annualBuckets.keys()]);
    const map = new Map();
    keys.forEach((key) => {
      const selectedRows = selectedBuckets.get(key) || [];
      const ytdRows = annualBuckets.get(key) || [];
      const first = selectedRows[0] || ytdRows[0];
      if (!first) return;
      map.set(key, {
        key, name:entityName(first), bir:first.bir, group:first.group, regional:first.region,
        mtd:combine(selectedRows), ytd:combine(ytdRows)
      });
    });
    const query = $('rankingSearch').value.trim().toLocaleLowerCase('pt-BR');
    const sort = $('rankingSort').value || 'mtd', order = $('rankingOrder').value || 'desc';
    const items = [...map.values()].filter((item) => `${item.name} ${item.bir || ''} ${item.group || ''}`.toLocaleLowerCase('pt-BR').includes(query));
    const value = (item) => sort === 'volume' ? item.mtd?.denominator : sort === 'ytd' ? item.ytd?.metric : item.mtd?.metric;
    items.sort((a,b) => {
      if (order === 'alpha') return a.name.localeCompare(b.name,'pt-BR');
      const av=value(a), bv=value(b);
      if (av == null || bv == null) return av == null && bv == null ? a.name.localeCompare(b.name,'pt-BR') : av == null ? 1 : -1;
      return (order === 'asc' ? av-bv : bv-av) || a.name.localeCompare(b.name,'pt-BR');
    });
    const annualLabel = state.period ? `Jan–${fmtMonthShort(state.period)}` : 'YTD';
    const selectedLabel = periodsSelected.length === 1 ? `MTD ${fmtPeriod(periodsSelected[0])}` : `Resultado selecionado (${periodsSelected.length} meses)`;
    const sortOption = [...$('rankingSort').options].find((option) => option.value === 'mtd');
    if (sortOption) sortOption.textContent = periodsSelected.length === 1 ? 'MTD' : 'Resultado selecionado';
    $('rankingTitle').textContent = `${processMeta().name} · ${state.entityLevel} · ${selectionPeriodLabel(periodsSelected)}`;
    $('rankingNote').textContent = periodsSelected.length === 1
      ? `Volume e MTD: ${fmtPeriod(periodsSelected[0])} · ${snapshotShort(snapshotForSelectionPeriod(periodsSelected[0]), periodsSelected[0])}. ${awaitsOfficial(state.process,periodsSelected[0]) ? 'D+15 pendente: usando último dia. ' : ''}YTD ${annualLabel}: ${ytdProcesses.has(state.process) ? 'posição da base anual mais recente, limitada ao mês selecionado.' : 'bases mensais disponíveis de janeiro até o mês selecionado; resultado ponderado pelos volumes.'}`
      : `Volume e resultado: ${periodsSelected.length} meses selecionados. YTD ${annualLabel}: ${ytdProcesses.has(state.process) ? 'posição da base anual mais recente, limitada ao último mês selecionado.' : 'bases mensais disponíveis de janeiro até o último mês selecionado; resultado ponderado pelos volumes.'}`;
    const cell = (row) => `<td class="metric ${row ? bandFor(state.process,row.metric) : 'neutral'}" title="${row ? `${fmtInt(row.denominator)} chassis na base` : 'Sem base disponível'}">${fmtPct(row?.metric)}</td>`;
    const shareCell = (item) => `<td title="${item.mtd ? `${fmtInt(item.mtd.denominator)} de ${fmtInt(rankingScopeVolume)} chassis elegíveis no escopo selecionado` : 'Sem volume no período selecionado'}">${item.mtd && rankingScopeVolume > 0 ? fmtPct(item.mtd.denominator / rankingScopeVolume) : '–'}</td>`;
    $('rankingTable').innerHTML = `<thead><tr><th>#</th><th>${state.entityLevel}</th><th>Volume selecionado</th><th>Participação no escopo (%)</th><th>${selectedLabel}</th><th>YTD ${annualLabel}</th></tr></thead><tbody>${items.map((item,i) => `<tr><td>${i+1}</td><td>${esc(item.name)}</td><td>${fmtInt(item.mtd?.denominator)}</td>${shareCell(item)}${cell(item.mtd)}${cell(item.ytd)}</tr>`).join('') || '<tr><td colspan="6">Nenhum resultado para os filtros selecionados.</td></tr>'}</tbody>`;
  }

  function overviewBreakdown(row, process) {
    if (!row) return 'Sem base disponível.';
    const lines=[];
    if(process === 'dda') {
      const labels={reception:'Recepção',preparation:'Preparação',delivery:'Entrega'};
      Object.entries(labels).forEach(([key,label]) => {const c=row.components[key];lines.push(`${label}: ${fmtInt(c?.numerator)} OK / ${fmtInt(c?.denominator)} · ${fmtPct(c?.metric)}`)});
      lines.push('DDA Total = média das três taxas.');
    } else {
      Object.entries(row.components || {}).forEach(([key,val]) => lines.push(`${key}: ${fmtInt(val)} chassis`));
      lines.push(`Realizados: ${fmtInt(row.numerator)} / ${fmtInt(row.denominator)} · ${fmtPct(row.metric)}`);
    }
    lines.push(`Total: ${fmtInt(row.denominator)} chassis · ${fmtPeriod(row.period)}`);
    return lines.join('\n');
  }
  function openOverviewDrill(process, region=null, view='performance', entity=null) {
    $('overviewTooltip').hidden = true;
    switchProcess(process);
    const processPeriods = state.data.availability[process]?.periods || [];
    const selectedPeriods = [...state.overviewPeriods].filter((period) => processPeriods.includes(period)).sort();
    state.periods = new Set(selectedPeriods.length ? selectedPeriods : (processPeriods.length ? [processPeriods.at(-1)] : []));
    state.period = selectedProcessPeriods().at(-1) || processPeriods.at(-1) || '';
    state.snapshot = preferredSnapshot(process, state.period) || 'ultimo_dia';
    state.regions=new Set(region ? [region] : state.overviewRegions);
    if(entity){
      state.entityLevel='Grupo';
      qsa('[data-toggle="entity"] button').forEach(b => b.classList.toggle('active',b.dataset.entity==='Grupo'));
      state.selectedEntity={...entity,key:entityKey(entity,'Grupo'),level:'Grupo',name:entityName(entity,'Grupo')};
      $('entitySearch').value=entity.group || entity.name;
    }
    updateProcessControls();
    activateView(view);
    const target=$(view === 'search' ? 'entityDetail' : view === 'snapshots' ? 'snapshotHistoryBlock' : 'performanceBlock');
    target.classList.remove('drill-flash');
    requestAnimationFrame(()=> {target.classList.add('drill-flash');target.scrollIntoView({behavior:'smooth',block:'center'});});
  }
  function attachOverviewHint(element,text,onClick) {
    if(!element) return;
    element.tabIndex=0;
    element.setAttribute('aria-describedby','overviewTooltip');
    const show=()=> {
      const tip=$('overviewTooltip');tip.textContent=text;tip.hidden=false;
      const rect=element.getBoundingClientRect();
      const left=Math.max(12,Math.min(rect.left,window.innerWidth-tip.offsetWidth-12));
      const top=rect.bottom+9+tip.offsetHeight > window.innerHeight ? Math.max(12,rect.top-tip.offsetHeight-9) : rect.bottom+9;
      tip.style.left=`${left}px`;tip.style.top=`${top}px`;
    };
    const hide=()=> {$('overviewTooltip').hidden=true;};
    element.addEventListener('mouseenter',show);element.addEventListener('mouseleave',hide);
    element.addEventListener('focus',show);element.addEventListener('blur',hide);
    if(onClick){element.dataset.drill='true';element.setAttribute('role','button');element.setAttribute('aria-label',text+' Abrir detalhamento.');element.addEventListener('click',onClick);element.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onClick();}});}
    element.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
  }
  function overviewAvailablePeriods() {
    return [...new Set(Object.values(state.data.availability).flatMap((item) => item.periods || []))].sort();
  }

  function renderOverviewFilters() {
    const periods = overviewAvailablePeriods();
    state.overviewPeriods = new Set([...state.overviewPeriods].filter((period) => periods.includes(period)));
    if (!state.overviewPeriods.size && periods.length) state.overviewPeriods.add(periods.at(-1));
    state.overviewRegions = new Set([...state.overviewRegions].filter((region) => state.data.regions.includes(region)));
    if (!state.overviewRegions.size) state.overviewRegions = new Set(state.data.regions);
    const allMonths = periods.length > 0 && periods.every((period) => state.overviewPeriods.has(period));
    $('overviewMonthChips').innerHTML = periods.map((period) => `<button type="button" class="${state.overviewPeriods.has(period) ? 'active' : ''}" data-overview-period="${period}">${fmtMonthShort(period).split('/')[0]}</button>`).join('') + `<button type="button" class="${allMonths ? 'active' : ''}" data-overview-period-action="all">Todos</button><button type="button" data-overview-period-action="latest">Mais atual</button>`;
    qsa('[data-overview-period]', $('overviewMonthChips')).forEach((button) => button.addEventListener('click', () => {
      const period = button.dataset.overviewPeriod;
      if (state.overviewPeriods.has(period)) {
        if (state.overviewPeriods.size === 1) return toast('Mantenha ao menos um mês no Resumo.');
        state.overviewPeriods.delete(period);
      } else state.overviewPeriods.add(period);
      renderOverview();
    }));
    qsa('[data-overview-period-action]', $('overviewMonthChips')).forEach((button) => button.addEventListener('click', () => {
      state.overviewPeriods = button.dataset.overviewPeriodAction === 'all' ? new Set(periods) : new Set(periods.length ? [periods.at(-1)] : []);
      renderOverview();
    }));
    const allRegions = state.data.regions.every((region) => state.overviewRegions.has(region));
    $('overviewRegionChips').innerHTML = state.data.regions.map((region) => `<button type="button" class="${state.overviewRegions.has(region) ? 'active' : ''}" data-overview-region="${region}">${region}</button>`).join('') + `<button type="button" class="${allRegions ? 'active' : ''}" data-overview-region-action="all">Todas</button>`;
    qsa('[data-overview-region]', $('overviewRegionChips')).forEach((button) => button.addEventListener('click', () => {
      const region = button.dataset.overviewRegion;
      if (state.overviewRegions.has(region)) {
        if (state.overviewRegions.size === 1) return toast('Mantenha ao menos uma regional no Resumo.');
        state.overviewRegions.delete(region);
      } else state.overviewRegions.add(region);
      renderOverview();
    }));
    qsa('[data-overview-region-action]', $('overviewRegionChips')).forEach((button) => button.addEventListener('click', () => {
      state.overviewRegions = new Set(state.data.regions);
      renderOverview();
    }));
    const selectedPeriods = [...state.overviewPeriods].sort();
    $('overviewFilterNote').textContent = `${selectedPeriods.length} ${selectedPeriods.length === 1 ? 'mês selecionado' : 'meses selecionados'} · ${state.overviewRegions.size} ${state.overviewRegions.size === 1 ? 'regional selecionada' : 'regionais selecionadas'} · resultados consolidados pelos volumes.`;
  }

  function overviewAggregates(process, level) {
    const records = [];
    [...state.overviewPeriods].sort().forEach((period) => {
      const snapshots = state.data.availability[process]?.snapshots?.[period] || [];
      if (!snapshots.length) return;
      const snapshot = preferredSnapshot(process, period);
      metricRows().filter((row) => row.process === process && row.period === period && row.snapshot === snapshot && row.level === level && (!row.region || state.overviewRegions.has(row.region))).forEach((row) => records.push(row));
    });
    if (level === 'Brasil') return records.length ? [combine(records, process)] : [];
    const buckets = new Map();
    records.forEach((row) => {
      const key = level === 'Regional' ? row.region : `${row.region}|${row.group || row.name}`;
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(row);
    });
    return [...buckets.values()].map((rows) => {
      const result = combine(rows, process);
      const first = rows[0];
      return {...result, level, name:level === 'Regional' ? first.region : (first.group || first.name), region:first.region, group:level === 'Grupo' ? (first.group || first.name) : ''};
    });
  }

  function overviewProcessData(process) {
    const regional = overviewAggregates(process, 'Regional');
    // Todas as regionais selecionadas: o Brasil DDA também inclui Grupo Network,
    // que deliberadamente não possui linha regional ou de grupo.
    const wholeBrazil = state.data.regions.every((region) => state.overviewRegions.has(region));
    const total = wholeBrazil ? overviewAggregates(process, 'Brasil')[0] || null : regional.length ? combine(regional, process) : null;
    return {total, regions:regional, groups:overviewAggregates(process, 'Grupo')};
  }

  function overviewSelectionLabels(process) {
    const periods = [...state.overviewPeriods].filter((period) => (state.data.availability[process]?.periods || []).includes(period)).sort();
    const period = periods.length === 1 ? fmtPeriod(periods[0]) : `${periods.length} meses`;
    const photo = periods.length === 1 ? snapshotShort(preferredSnapshot(process, periods[0]), periods[0]) : 'Melhor disponível/mês';
    return {periods, period, photo};
  }

  function enhanceOverview() {
    qsa('[data-overview-process]', $('overviewCards')).forEach(card=>{
      const process=card.dataset.overviewProcess, data=overviewProcessData(process), row=data.total;
      if(!row)return;
      const labels=overviewSelectionLabels(process), info=overviewBreakdown(row,process), open=()=>openOverviewDrill(process);
      attachOverviewHint(card.querySelector('.overview-result'),info+'\nClique para abrir Brasil e Regionais no mês mais recente da seleção.',open);
      attachOverviewHint(card.querySelector('.overview-meter'),`Resultado: ${fmtPct(row.metric)}. Objetivo: ${state.data.processes[process].target == null ? 'não definido' : fmtPct(state.data.processes[process].target)}.`,open);
      attachOverviewHint(card.querySelector('.status-pill'),info,open);
      qsa('.overview-components>div',card).forEach(element=>{
        const label=element.querySelector('span').textContent;
        let detail=info;
        if(process==='dda'){
          const key={Recepção:'reception',Preparação:'preparation',Entrega:'delivery'}[label];
          const c=row.components[key];detail=`${label}: ${fmtInt(c?.numerator)} OK, ${fmtInt((c?.denominator||0)-(c?.numerator||0))} não OK, ${fmtInt(c?.denominator)} no total.\nResultado: ${fmtPct(c?.metric)}.`;
        }else{
          const count=label==='Total Pareado'?row.numerator:row.components[label];
          detail=`${label}: ${fmtInt(count)} chassis de ${fmtInt(row.denominator)}.\n${fmtPct(row.denominator ? count/row.denominator : null)} do total.`;
        }
        attachOverviewHint(element,detail+'\nClique para ver a composição.',open);
      });
      qsa('.overview-meta>div',card).forEach(element=>{
        const label=element.querySelector('span').textContent;
        const text=label==='Comparação' ? 'Abra a evolução dos fechamentos para comparar último dia, D+15 e YTD quando aplicável.' : label==='Fotografia' ? `Origem: ${labels.photo}.` : label==='Período' ? `Seleção: ${labels.periods.map(fmtPeriod).join(', ')}.` : info;
        attachOverviewHint(element,text,()=>openOverviewDrill(process,null,label==='Comparação'?'snapshots':'performance'));
      });
      const regionBox=card.querySelector('.overview-regional');
      const regions=data.regions.filter((row) => row.metric != null).sort((a,b)=>b.metric-a.metric||a.name.localeCompare(b.name));
      const groups=data.groups.filter((row) => row.metric != null);
      attachOverviewHint(regionBox.firstElementChild,regions.map(r=>`${r.name}: ${fmtPct(r.metric)} · ${fmtInt(r.denominator)} chassis`).join('\n'),open);
      [[regions[0],true],[regions.at(-1),false]].forEach(([region,best])=>{
        if(!region)return;
        const contributors=groups.filter((row)=>row.region===region.name).sort((a,b)=>(best ? b.metric-a.metric : a.metric-b.metric)||b.denominator-a.denominator).slice(0,4);
        const detail=document.createElement('details');detail.className='overview-contributors';
        detail.innerHTML=`<summary><span>${best?'Melhor resultado':'Menor resultado'}</span><strong>${esc(region.name)} · <b class="metric ${region.band}">${fmtPct(region.metric)}</b></strong></summary><div class="overview-group-list"><small>${best?'Promotores · maiores resultados':'Detratores · menores resultados'} na região</small>${contributors.map((g,i)=>`<button type="button" data-group-index="${i}"><span>${esc(g.group||g.name)}</span><b class="metric ${g.band}">${fmtPct(g.metric)}</b></button>`).join('')}</div>`;
        regionBox.appendChild(detail);
        attachOverviewHint(detail.querySelector('summary'),overviewBreakdown(region,process)+'\nAbra a seta para ver os quatro grupos.');
        qsa('[data-group-index]',detail).forEach(button=>{const g=contributors[Number(button.dataset.groupIndex)];attachOverviewHint(button,overviewBreakdown(g,process)+'\nClique para consultar o grupo.',()=>openOverviewDrill(process,region.name,'search',g));});
      });
      const top=groups.slice().sort((a,b)=>b.metric-a.metric||b.denominator-a.denominator).slice(0,4);
      const flop=groups.slice().sort((a,b)=>a.metric-b.metric||b.denominator-a.denominator).slice(0,4);
      const topFlop=document.createElement('details');topFlop.className='overview-contributors';
      topFlop.innerHTML=`<summary><span>Top/Flop</span><strong>4 + 4 grupos</strong></summary><div class="overview-group-list overview-topflop-grid"><small>Grupos nas regionais e meses selecionados</small><div class="overview-topflop-column"><span>Top 4</span>${top.map((g,i)=>`<button type="button" data-top-group="${i}"><span>${esc(g.group||g.name)}</span><b class="metric ${g.band}">${fmtPct(g.metric)}</b></button>`).join('')}</div><div class="overview-topflop-column"><span>Flop 4</span>${flop.map((g,i)=>`<button type="button" data-flop-group="${i}"><span>${esc(g.group||g.name)}</span><b class="metric ${g.band}">${fmtPct(g.metric)}</b></button>`).join('')}</div></div>`;
      regionBox.appendChild(topFlop);
      attachOverviewHint(topFlop.querySelector('summary'),'Abra para consultar os quatro melhores e os quatro menores resultados de grupos no filtro atual.');
      qsa('[data-top-group]',topFlop).forEach(button=>{const g=top[Number(button.dataset.topGroup)];attachOverviewHint(button,overviewBreakdown(g,process),()=>openOverviewDrill(process,g.region,'search',g));});
      qsa('[data-flop-group]',topFlop).forEach(button=>{const g=flop[Number(button.dataset.flopGroup)];attachOverviewHint(button,overviewBreakdown(g,process),()=>openOverviewDrill(process,g.region,'search',g));});
    });
  }

  function renderOverview() {
    if (!state.data) return;
    renderOverviewFilters();
    const processOrder = ['conectividade', 'dda', 'battery_check', 'ltsm'];
    const processData = Object.fromEntries(processOrder.map((process) => [process, overviewProcessData(process)]));
    const targetRows = processOrder.map((process) => ({process, meta:state.data.processes[process], row:processData[process].total})).filter((item) => item.meta?.target != null && item.row);
    const goalsMet = targetRows.filter((item) => item.row.band === 'good').length;
    $('overviewGoalCount').textContent = targetRows.length ? `${goalsMet} de ${targetRows.length}` : '–';
    $('overviewGoalLabel').textContent = targetRows.length ? 'processos com meta no objetivo' : 'nenhum processo com meta definida';

    $('overviewCards').innerHTML = processOrder.map((process) => {
      const meta = state.data.processes[process], data=processData[process], row=data.total, labels=overviewSelectionLabels(process);
      if (!meta || !row) return `<article class="overview-card overview-card-empty" style="--card-color:${meta?.color || '#7a7f87'};--card-soft:${processSoftColors[process] || '#eceef1'}"><div class="overview-card-head"><div><p class="eyebrow">PROCESSO</p><h3>${esc(meta?.name || process)}</h3></div><span class="status-pill neutral">Sem dados</span></div><p class="overview-empty-text">Nenhum resultado válido foi encontrado para os meses e regionais selecionados.</p></article>`;
      const regionalRows=data.regions.filter((item)=>item.metric!=null), regionalGoal=regionalRows.filter((item)=>item.band==='good').length;
      const targetText = `Meta ${fmtPct(meta.target)}`, meter=Math.max(0,Math.min(100,row.metric*100));
      const marker=`<i style="left:${Math.max(0,Math.min(100,meta.target*100))}%" title="Meta ${fmtPct(meta.target)}"></i>`;
      const regionalText=`${regionalGoal} de ${regionalRows.length} no objetivo`;
      return `<article class="overview-card" data-overview-process="${process}" style="--card-color:${meta.color};--card-soft:${processSoftColors[process] || '#eceef1'}">
        <div class="overview-card-head"><div><p class="eyebrow">PROCESSO</p><h3>${esc(meta.name)}</h3></div><span class="status-pill ${row.band}">${bandLabel(row.band)}</span></div>
        <div class="overview-result"><strong class="metric ${row.band}">${fmtPct(row.metric)}</strong><span>${targetText}</span></div>
        <div class="overview-meter" aria-label="Resultado ${fmtPct(row.metric)}"><span style="width:${meter}%"></span>${marker}</div>
        <div class="overview-meta"><div><span>Período</span><strong>${labels.period}</strong></div><div><span>Fotografia</span><strong>${labels.photo}</strong></div><div><span>Volume</span><strong>${fmtInt(row.denominator)} chassis</strong></div><div><span>Comparação</span><strong class="delta-flat">Consultar evolução</strong></div></div>
        <div class="overview-components">${overviewComponentMarkup(process,row,meta)}</div>
        <div class="overview-regional"><div><span>Regionais</span><strong>${regionalText}</strong></div></div>
        <button type="button" class="overview-open" data-open-process="${process}">Abrir ${esc(meta.name)} <span>→</span></button>
      </article>`;
    }).join('');
    enhanceOverview();
    qsa('[data-open-process]', $('overviewCards')).forEach((button) => button.addEventListener('click', () => openOverviewDrill(button.dataset.openProcess)));
  }

  function groupSummaryEntities() {
    const level = state.groupSummaryLevel;
    const unique = new Map();
    if (isGroupReport) {
      const scoped = state.data.group_report;
      if (level === 'Grupo') {
        const key = `${scoped.region}|${scoped.group}`;
        unique.set(key, {key, level, name:scoped.group, region:scoped.region, group:scoped.group, dealer:'', bir:''});
      } else {
        (scoped.dealers || []).forEach(item => {
          const key = String(item.bir);
          unique.set(key, {key, level, name:item.dealer, region:scoped.region, group:scoped.group, dealer:item.dealer, bir:item.bir});
        });
      }
    }
    (state.data?.metrics || []).filter(row => row.level === level).forEach((row) => {
      const key = level === 'Grupo' ? `${row.region}|${row.group}` : String(row.bir || `${row.region}|${row.group}|${row.dealer}`);
      if (!unique.has(key)) unique.set(key, {key, level, name: level === 'Grupo' ? row.group : row.dealer,
        region:row.region, group:row.group, dealer:row.dealer, bir:row.bir});
    });
    return [...unique.values()].sort((a,b)=>a.name.localeCompare(b.name,'pt-BR'));
  }

  function groupSummarySnapshotRows(process, level, predicate) {
    const rows = [];
    [...state.overviewPeriods].sort().forEach(period => {
      if (!processPeriods(process).includes(period)) return;
      const snapshot = preferredSnapshot(process, period);
      metricRows().filter(row => row.process === process && row.level === level && row.period === period && row.snapshot === snapshot && predicate(row)).forEach(row=>rows.push(row));
    });
    return rows;
  }

  function renderGroupSummary() {
    if (!state.data || !$('groupSummaryCards')) return;
    const periodChoices = overviewAvailablePeriods();
    $('groupSummaryMonths').innerHTML = periodChoices.map(period => `<button type="button" class="${state.overviewPeriods.has(period)?'active':''}" data-summary-month="${period}">${fmtMonthShort(period)}</button>`).join('') +
      `<button type="button" data-summary-month-action="all">Todos</button><button type="button" data-summary-month-action="latest">Mais atual</button>`;
    qsa('[data-summary-month]', $('groupSummaryMonths')).forEach(button=>button.addEventListener('click',()=>{
      const period=button.dataset.summaryMonth;
      if(state.overviewPeriods.has(period)){if(state.overviewPeriods.size===1)return;state.overviewPeriods.delete(period);}
      else state.overviewPeriods.add(period);
      renderOverview();renderGroupSummary();
    }));
    qsa('[data-summary-month-action]', $('groupSummaryMonths')).forEach(button=>button.addEventListener('click',()=>{
      state.overviewPeriods=new Set(button.dataset.summaryMonthAction==='all'?periodChoices:periodChoices.slice(-1));
      renderOverview();renderGroupSummary();
    }));
    const entities = groupSummaryEntities();
    if (isGroupReport && state.groupSummaryLevel === 'Grupo' && !state.groupSummaryKey) {
      state.groupSummaryKey = `${state.data.group_report.region}|${state.data.group_report.group}`;
    }
    const query = $('groupSummarySearch').value.toLocaleLowerCase('pt-BR').trim();
    const choices = query ? entities.filter(e=>`${e.name} ${e.group} ${e.bir}`.toLocaleLowerCase('pt-BR').includes(query)) : entities;
    $('groupSummaryEntity').innerHTML = '<option value="">Selecione...</option>' + choices.map(e=>`<option value="${esc(e.key)}">${esc(e.name)} · ${esc(e.region)}${e.level==='Concessionária'?` · ${esc(e.bir)}`:''}</option>`).join('');
    if (state.groupSummaryKey && !choices.some(e=>e.key===state.groupSummaryKey)) {
      const selected=entities.find(e=>e.key===state.groupSummaryKey);
      if(selected)$('groupSummaryEntity').insertAdjacentHTML('beforeend',`<option value="${esc(selected.key)}">${esc(selected.name)} · ${esc(selected.region)}</option>`);
    }
    $('groupSummaryEntity').value=state.groupSummaryKey;
    const entity=entities.find(e=>e.key===state.groupSummaryKey);
    if(!entity){
      $('groupSummaryDescription').textContent='Selecione um grupo ou concessionária para comparar os quatro processos.';
      $('groupSummaryCards').innerHTML='<div class="empty-state">Escolha um grupo ou concessionária no filtro acima.</div>';
      return;
    }
    $('groupSummaryDescription').textContent=`${entity.name} · ${entity.region} · ${state.overviewPeriods.size} mês(es) · ${state.model||'Todos os modelos'}`;
    const processOrder=['conectividade','dda','battery_check','ltsm'];
    $('groupSummaryCards').innerHTML=processOrder.map(process=>{
      const meta=state.data.processes[process];
      const own=combine(groupSummarySnapshotRows(process,entity.level,row=>entity.level==='Grupo'
        ? row.region===entity.region&&row.group===entity.group
        : row.region===entity.region&&row.bir===entity.bir),process);
      const regional=combine(groupSummarySnapshotRows(process,'Regional',row=>row.region===entity.region),process);
      const group=entity.level==='Concessionária'
        ? combine(groupSummarySnapshotRows(process,'Grupo',row=>row.region===entity.region&&row.group===entity.group),process) : null;
      const dealerRows=entity.level==='Grupo' ? groupSummarySnapshotRows(process,'Concessionária',row=>row.region===entity.region&&row.group===entity.group):[];
      const buckets=new Map();
      dealerRows.forEach(row=>{const key=row.bir||row.dealer;if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(row);});
      const list=[...buckets.values()].map(items=>({name:items[0].dealer, bir:items[0].bir, score:combine(items,process)})).filter(item=>item.score?.metric!=null);
      const sorted=list.slice().sort((a,b)=>b.score.metric-a.score.metric||a.name.localeCompare(b.name));
      const top=sorted.slice(0,4), flop=sorted.slice(-4).reverse();
      const scopeMarkup=entity.level==='Grupo' ?
        `<div class="overview-regional"><div><span>Regional ${esc(entity.region)}</span><strong class="metric ${bandFor(process,regional?.metric)}">${fmtPct(regional?.metric)}</strong></div></div>
         <details class="overview-contributors"><summary><span>Top/Flop concessionárias</span><strong>${list.length} lojas</strong></summary>
           <div class="overview-group-list overview-topflop-grid"><div class="overview-topflop-column"><span>Top 4</span>${top.map(item=>`<div><span>${esc(item.name)}</span><b class="metric ${item.score.band}">${fmtPct(item.score.metric)}</b></div>`).join('')}</div>
           <div class="overview-topflop-column"><span>Flop 4</span>${flop.map(item=>`<div><span>${esc(item.name)}</span><b class="metric ${item.score.band}">${fmtPct(item.score.metric)}</b></div>`).join('')}</div></div></details>` :
        `<div class="overview-regional"><div><span>Regional ${esc(entity.region)}</span><strong class="metric ${bandFor(process,regional?.metric)}">${fmtPct(regional?.metric)}</strong></div><div><span>Grupo ${esc(entity.group)}</span><strong class="metric ${bandFor(process,group?.metric)}">${fmtPct(group?.metric)}</strong></div></div>`;
      return `<article class="overview-card" style="--card-color:${meta.color};--card-soft:${processSoftColors[process]}">
        <div class="overview-card-head"><div><p class="eyebrow">PROCESSO</p><h3>${esc(meta.name)}</h3></div><span class="status-pill ${bandFor(process,own?.metric)}">${own?.metric != null ? bandLabel(own.band) : 'Sem dados'}</span></div>
        <div class="overview-result"><strong class="metric ${bandFor(process,own?.metric)}">${fmtPct(own?.metric)}</strong><span>Meta ${fmtPct(meta.target)}</span></div>
        <div class="overview-meter"><span style="width:${Math.max(0,Math.min(100,(own?.metric||0)*100))}%"></span><i style="left:${meta.target*100}%"></i></div>
        <div class="overview-meta"><div><span>Período</span><strong>${state.overviewPeriods.size} mês(es)</strong></div><div><span>Fotografia</span><strong>Melhor disponível/mês</strong></div><div><span>Volume</span><strong>${fmtInt(own?.denominator)} chassis</strong></div></div>
        <div class="overview-components">${own?overviewComponentMarkup(process,own,meta):'<p>Sem bases para a seleção.</p>'}</div>${scopeMarkup}
      </article>`;
    }).join('');
  }

  function updateSnapshotToggle() {
    if (!$('snapshotToggle') || !state.data) return;
    const periods = selectedProcessPeriods();
    const allowYtd = state.view === 'performance' && ytdProcesses.has(state.process);
    const order = ['parcial','ultimo_dia','oficial','ytd_atual'];
    const candidates = new Set();
    periods.forEach((period) => effectiveSnapshots(state.process, period, allowYtd).forEach((snapshot) => candidates.add(snapshot)));
    const snapshots = order.filter((snapshot) => candidates.has(snapshot));
    if (state.snapshot === 'ytd_atual' && !allowYtd) state.snapshot = preferredSnapshot(state.process, state.period) || 'ultimo_dia';
    if (!snapshots.includes(state.snapshot)) state.snapshot = preferredSnapshot(state.process, state.period, state.snapshot) || snapshots[0] || 'ultimo_dia';
    const label = (snapshot) => snapshot === 'ytd_atual' ? 'YTD mais atual' : snapshot === 'oficial' ? 'Fechamento D+15' : snapshot === 'ultimo_dia' ? (periods.length > 1 ? 'Último dia / parcial' : snapshotShort(snapshot, state.period)) : 'Parcial';
    $('snapshotToggle').innerHTML = snapshots.map((snapshot) => `<button type="button" class="${snapshot === state.snapshot ? 'active' : ''}" data-snapshot="${snapshot}">${label(snapshot)}</button>`).join('') || '<button type="button" class="active">Sem dados</button>';
    qsa('[data-snapshot]', $('snapshotToggle')).forEach((button) => button.addEventListener('click', () => {
      state.snapshot = button.dataset.snapshot;
      state.selectedEntity = null;
      qsa('[data-snapshot]', $('snapshotToggle')).forEach((item) => item.classList.toggle('active', item === button));
      renderAll();
    }));
  }

  function renderRegionChips() {
    $('regionChips').innerHTML = state.data.regions.map((region) => `<button type="button" class="filter-chip ${state.regions.has(region) ? 'active' : ''}" data-region="${region}">${region}</button>`).join('');
    qsa('[data-region]', $('regionChips')).forEach((button) => button.addEventListener('click', () => {
      const region = button.dataset.region;
      if (state.regions.has(region)) {
        if (state.regions.size === 1) { toast('Mantenha ao menos uma regional selecionada.'); return; }
        state.regions.delete(region);
      } else state.regions.add(region);
      state.selectedEntity = null;
      button.classList.toggle('active', state.regions.has(region));
      renderAll();
    }));
  }

  function activeRows(level) {
    const periods = new Set(selectedProcessPeriods());
    return metricRows().filter((row) => row.process === state.process && periods.has(row.period) && row.snapshot === snapshotForSelectionPeriod(row.period) && (!level || row.level === level));
  }

  function groupCombinedRows(rows, level) {
    const buckets = new Map();
    rows.forEach((row) => {
      const key = level === 'Regional' ? row.region : entityKey(row, level);
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(row);
    });
    return [...buckets.values()].map((items) => {
      const result = combine(items, state.process);
      const first = items[0];
      return {...result, level, name:level === 'Regional' ? first.region : entityName(first, level), region:first.region, group:first.group, dealer:first.dealer, bir:first.bir};
    });
  }

  function bandFor(process, metric) {
    if (metric == null) return 'neutral';
    const meta = state.data.processes[process];
    if (meta.target == null) return 'neutral';
    if (process === 'dda') return metric >= meta.target ? 'good' : metric >= meta.attention ? 'attention' : 'bad';
    return metric >= meta.target ? 'good' : 'bad';
  }

  function combine(rows, process = state.process) {
    if (!rows.length) return null;
    const result = {process, period:rows.at(-1).period, snapshot:rows.at(-1).snapshot, level:'Brasil', name:'Seleção', numerator:0, denominator:0, metric:null, components:{}};
    if (process === 'dda') {
      ['reception', 'preparation', 'delivery'].forEach((module) => {
        const numerator = rows.reduce((sum, row) => sum + (row.components?.[module]?.numerator || 0), 0);
        const denominator = rows.reduce((sum, row) => sum + (row.components?.[module]?.denominator || 0), 0);
        const metric = denominator ? numerator / denominator : null;
        result.components[module] = {numerator, denominator, metric, band:bandFor(process, metric)};
      });
      const rates = Object.values(result.components).map((item) => item.metric);
      const availableRates = rates.filter((value) => value != null);
      result.metric = availableRates.length ? availableRates.reduce((sum, value) => sum + value, 0) / availableRates.length : null;
      result.denominator = rows.reduce((sum, row) => sum + (row.denominator || 0), 0);
      result.band = bandFor(process, result.metric);
      return result;
    }
    rows.forEach((row) => {
      result.numerator += row.numerator || 0;
      result.denominator += row.denominator || 0;
      Object.entries(row.components || {}).forEach(([key, value]) => { result.components[key] = (result.components[key] || 0) + value; });
    });
    result.metric = result.denominator ? result.numerator / result.denominator : null;
    result.band = bandFor(process, result.metric);
    return result;
  }

  function selectedTotal() {
    if (isGroupReport) return combine(activeRows('Grupo').filter(row => row.region === state.data.group_report.region && row.group === state.data.group_report.group), state.process);
    const regionalRows = activeRows('Regional').filter(selectedRegions);
    // DDA e BC incluem Grupo Network no consolidado Brasil: quando todas as
    // regionais estão selecionadas, o Brasil vem das linhas nacionais de cada mês.
    if (state.regions.size === state.data.regions.length) return combine(activeRows('Brasil'), state.process) || combine(regionalRows, state.process);
    return combine(regionalRows, state.process);
  }

  function renderAll() {
    renderYtdCard();
    renderPerformance();
    renderSnapshotHistory();
    renderTimeline();
    renderRanking();
    renderTopFlop();
    renderSearch();
    renderChassis();
  }

  function ytdRowForProcess(process) {
    if (isGroupReport) return combine(metricRows().filter(row => row.process === process && row.level === 'Grupo' && row.group === state.data.group_report.group && row.region === state.data.group_report.region && row.snapshot === 'ytd_atual'), process);
    if (state.model) {
      const rows = metricRows().filter(row => row.process === process && row.level === 'Brasil' && row.snapshot === 'ytd_atual');
      return combine(rows, process);
    }
    const direct = state.data.ytd?.[process];
    if (Array.isArray(direct)) return direct.find((row) => row.level === 'Brasil') || direct[0] || null;
    if (direct) return direct;
    return metricRows().find((row) => row.process === process && row.level === 'Brasil' && ['ytd', 'ytd_atual', 'ytdc'].includes(String(row.snapshot || '').toLowerCase())) || null;
  }

  function renderYtdCard() {
    const card = $('ytdLiveCard');
    const supported = ['conectividade', 'ltsm'].includes(state.process);
    card.hidden = !supported;
    if (!supported) return;
    const row = ytdRowForProcess(state.process);
    const year = dataReferencePeriod().split('-')[0] || '–';
    if (!row) {
      card.className = 'ytd-live-card empty';
      card.innerHTML = `<div class="ytd-heading"><span>VISÃO ANUAL DINÂMICA</span><h3>YTD ${year} atualizado</h3><p>Posição extraída no dia, independente das bases mensais congeladas.</p></div><div class="ytd-result"><span>Resultado YTD</span><strong>Aguardando a base YTD deste processo</strong><p>Este espaço não soma os fechamentos mensais.</p></div>`;
      return;
    }
    card.className = 'ytd-live-card';
    const meta = state.data.processes[state.process];
    card.innerHTML = `<div class="ytd-heading"><span>VISÃO ANUAL DINÂMICA</span><h3>YTD ${year} atualizado</h3><p>Resultado extraído no dia, sem somar as fotografias congeladas.</p></div><div><span>Resultado YTD</span><strong class="metric ${bandFor(state.process, row.metric)}">${fmtPct(row.metric)}</strong></div><div><span>Volume</span><strong>${fmtInt(row.denominator)} chassis</strong></div><div><span>Objetivo</span><strong>${meta.target == null ? 'Sem meta' : fmtPct(meta.target)}</strong></div>`;
  }

  function renderPerformance() {
    const periods = selectedProcessPeriods();
    const total = selectedTotal();
    const rows = groupCombinedRows(activeRows('Regional').filter(selectedRegions), 'Regional').sort((a, b) => a.name.localeCompare(b.name));
    const photo = state.snapshot === 'ytd_atual' ? 'YTD mais atual' : periods.length === 1 ? snapshotLabel(snapshotForSelectionPeriod(periods[0]), periods[0]) : 'Fotografia selecionada por mês';
    $('performancePeriodTitle').textContent = `${processMeta().name} · ${selectionPeriodLabel(periods)} · ${photo}`;
    const pending = periods.some((period) => awaitsOfficial(state.process, period));
    $('performanceRangeNote').textContent = (pending ? 'Há mês encerrado com D+15 pendente; nesses casos é utilizado o último dia. ' : '') + (processMeta().target == null ? 'Indicador sem objetivo definido' : `Objetivo do processo: ${fmtPct(processMeta().target)}`);
    if (isGroupReport) {
      const audience = state.data.group_report;
      const brazil = combine(activeRows('Brasil'), state.process);
      const regional = combine(activeRows('Regional').filter(r => r.region === audience.region), state.process);
      const dealers = groupCombinedRows(activeRows('Concessionária').filter(r => r.region === audience.region && r.group === audience.group), 'Concessionária')
        .sort((a,b) => a.name.localeCompare(b.name,'pt-BR'));
      $('performanceTableTitle').textContent = `${processMeta().name} · ${audience.group} e concessionárias`;
      $('regionalTable').innerHTML = tableHead('Escopo') + `<tbody>${total ? resultRow(total, audience.group, true) : ''}`
        + `${regional ? resultRow(regional, 'Regional ' + audience.region) : ''}`
        + `${brazil ? resultRow(brazil, 'Brasil (referência)') : ''}`
        + `${dealers.map(row => resultRow(row, row.name)).join('')}</tbody>`;
    } else {
      $('performanceTableTitle').textContent = `${processMeta().name} · Desempenho Brasil e Regional`;
      $('regionalTable').innerHTML = tableHead('Regional') + `<tbody>${total ? resultRow(total, 'Brasil (Total geral)', true) : ''}${rows.map((row) => resultRow(row, row.name)).join('')}</tbody>`;
    }
  }

  function renderSnapshotScopeControl() {
    const select = $('snapshotScopeSelect');
    if (!select || !state.data) return;
    const scopes = isGroupReport ? ['Grupo', ...(state.data.regions || []), 'Brasil'] : ['Brasil', ...(state.data.regions || [])];
    if (!scopes.includes(state.snapshotScope)) state.snapshotScope = isGroupReport ? 'Grupo' : 'Brasil';
    select.innerHTML = scopes.map((scope) => `<option value="${esc(scope)}">${esc(scope === 'Grupo' ? state.data.group_report.group : scope === 'Brasil' ? 'Brasil · Total geral' : `Regional ${scope}`)}</option>`).join('');
    select.value = state.snapshotScope;
  }

  function snapshotHistoryRow(period, snapshot) {
    const level = state.snapshotScope === 'Brasil' ? 'Brasil' : state.snapshotScope === 'Grupo' && isGroupReport ? 'Grupo' : 'Regional';
    return metricRows().find((row) => {
      if (row.process !== state.process || row.period !== period || row.snapshot !== snapshot || row.level !== level) return false;
      if (level === 'Grupo') return row.region === state.data.group_report.region && row.group === state.data.group_report.group;
      return level === 'Brasil' ? true : row.region === state.snapshotScope || row.name === state.snapshotScope;
    }) || null;
  }

  function snapshotExtractionDate() {
    const date = new Date(state.data.generated_at);
    return Number.isNaN(date.getTime()) ? 'extração mais recente' : `extraído em ${date.toLocaleDateString('pt-BR')}`;
  }

  function snapshotMetricCell(row, missingText = 'Não disponível') {
    if (!row || row.metric == null) return `<td class="snapshot-na">–<small>${esc(missingText)}</small></td>`;
    return `<td class="metric ${bandFor(state.process, row.metric)}">${fmtPct(row.metric)}<small>${fmtInt(row.denominator)} chassis${row.provisional ? ' · último dia; D+15 pendente' : ''}</small></td>`;
  }

  function snapshotDeltaCell(value, missingText = 'Sem comparação') {
    return value == null
      ? `<td class="snapshot-na">–<small>${esc(missingText)}</small></td>`
      : `<td class="${deltaClass(value)}">${fmtPp(value)}</td>`;
  }

  function drawSnapshotHistoryChart(comparisons, series) {
    const element = $('snapshotHistoryChart');
    if (!element) return;
    if (!comparisons.length) {
      element.innerHTML = '<div class="empty-state">Sem meses disponíveis para comparação.</div>';
      return;
    }
    const width = 1080, height = 300, padding = {left:52, right:24, top:24, bottom:42};
    const x = (index) => padding.left + (comparisons.length === 1 ? (width - padding.left - padding.right) / 2 : index * (width - padding.left - padding.right) / (comparisons.length - 1));
    const y = (value) => padding.top + (1 - Math.max(0, Math.min(1, value ?? 0))) * (height - padding.top - padding.bottom);
    let grid = '';
    [0, .25, .5, .75, 1].forEach((value) => {
      grid += `<line class="grid" x1="${padding.left}" x2="${width - padding.right}" y1="${y(value)}" y2="${y(value)}"/><text x="${padding.left - 9}" y="${y(value) + 4}" text-anchor="end">${value * 100}%</text>`;
    });
    const selectedIndex = comparisons.findIndex((item) => item.period === state.period);
    const selectedMark = selectedIndex < 0 ? '' : `<line x1="${x(selectedIndex)}" x2="${x(selectedIndex)}" y1="${padding.top}" y2="${height - padding.bottom}" stroke="rgba(0,0,0,.10)" stroke-width="20"/>`;
    const target = processMeta().target;
    const targetLine = target == null ? '' : `<line x1="${padding.left}" x2="${width - padding.right}" y1="${y(target)}" y2="${y(target)}" stroke="#111" stroke-dasharray="6 5"/><text x="${width - padding.right}" y="${y(target) - 7}" text-anchor="end">Meta ${fmtPct(target)}</text>`;
    const seriesMarkup = series.map((definition) => {
      const points = comparisons.map((item, index) => ({index, value:item[definition.key]?.metric})).filter((point) => point.value != null);
      if (!points.length) return '';
      const polyline = points.map((point) => `${x(point.index)},${y(point.value)}`).join(' ');
      return `<polyline fill="none" stroke="${definition.color}" stroke-width="3" ${definition.dash ? `stroke-dasharray="${definition.dash}"` : ''} points="${polyline}"/>${points.map((point) => `<circle cx="${x(point.index)}" cy="${y(point.value)}" r="${comparisons[point.index].period === state.period ? 6 : 4.5}" fill="${definition.color}" stroke="#fff" stroke-width="2"><title>${esc(definition.label)}${comparisons[point.index][definition.key]?.provisional ? ' (último dia; D+15 pendente)' : ''} · ${fmtPeriod(comparisons[point.index].period)} · ${fmtPct(point.value)}</title></circle>`).join('')}`;
    }).join('');
    const monthLabels = comparisons.map((item, index) => `<text x="${x(index)}" y="${height - 14}" text-anchor="middle" font-weight="${item.period === state.period ? '900' : '600'}">${fmtMonthShort(item.period)}</text>`).join('');
    element.innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Comparação das fotografias mensais">${grid}${selectedMark}${targetLine}${seriesMarkup}${monthLabels}</svg>`;
  }

  function renderSnapshotHistory() {
    if (!state.data || !$('snapshotHistoryTable')) return;
    renderSnapshotScopeControl();
    const periods = selectedProcessPeriods();
    const supportsD15 = state.process !== 'conectividade';
    const supportsYtd = ['conectividade', 'ltsm'].includes(state.process);
    $('snapshotHistoryNote').innerHTML = '<span>i</span><p>' + (state.process === 'conectividade' ? '<strong>YTD mais atual</strong> mostra cada mês recalculado pela última base anual recebida, comparado ao último dia. O mês atual usa a última parcial. Conectividade não utiliza D+15.' : supportsYtd ? '<strong>YTD mais atual</strong> mostra cada mês recalculado pela última base anual recebida. O mês atual usa a última parcial. D+15 pendente usa o último dia provisoriamente; a origem permanece identificada.' : `${processMeta().name} compara último dia e D+15. O mês atual usa a última parcial. Enquanto o D+15 não estiver disponível, exibimos o último dia identificado como provisório.`) + '</p>';
    const comparisons = periods.map((period) => ({
      period,
      lastDay:isCurrentPeriod(period) ? snapshotHistoryRow(period, preferredSnapshot(state.process,period)) : snapshotHistoryRow(period, 'ultimo_dia'),
      d15:!isCurrentPeriod(period) && supportsD15 ? (snapshotHistoryRow(period, 'oficial') || provisionalRow(snapshotHistoryRow(period, 'ultimo_dia'))) : null,
      ytd:supportsYtd ? snapshotHistoryRow(period, 'ytd_atual') : null
    }));
    const selected = comparisons.find((item) => item.period === state.period) || comparisons[comparisons.length - 1] || {period:state.period, lastDay:null, d15:null, ytd:null};
    const latestAvailable = selected.ytd || selected.d15 || selected.lastDay;
    const totalDelta = !latestAvailable?.provisional && !isCurrentPeriod(selected.period) && selected.lastDay?.metric != null && latestAvailable?.metric != null ? latestAvailable.metric - selected.lastDay.metric : null;
    const cards = [
      {label:isCurrentPeriod(selected.period) ? 'Mês atual · parcial' : 'Último dia do mês', row:selected.lastDay, color:'#6f747a', missing:isCurrentPeriod(selected.period) ? 'Mês ainda em andamento' : 'Base não disponível'},
      {label:'Fechamento D+15', row:selected.d15, color:'#c3a400', missing:supportsD15 ? (isCurrentPeriod(selected.period) ? 'Ainda não aplicável' : 'Base não disponível') : 'Não se aplica'},
      {label:'YTD mais atual', row:selected.ytd, color:processMeta().color, missing:supportsYtd ? 'Base YTD não disponível' : 'Não se aplica'},
      {label:'Variação total', delta:totalDelta, color:'#111', missing:isCurrentPeriod(selected.period) ? 'Aguardando fechamento' : 'Sem fotografias comparáveis'}
    ];
    $('snapshotSummaryCards').innerHTML = cards.filter((card) => !(card.label === 'Fechamento D+15' && !supportsD15) && !(card.label === 'YTD mais atual' && !supportsYtd)).map((card) => {
      const available = card.row?.metric != null || card.delta != null;
      const value = card.delta != null ? fmtPp(card.delta) : card.row?.metric != null ? fmtPct(card.row.metric) : 'Indisponível';
      const valueClass = card.delta != null ? deltaClass(card.delta) : card.row ? `metric ${bandFor(state.process, card.row.metric)}` : '';
      const detail = card.row ? `${fmtInt(card.row.denominator)} chassis${card.row.provisional ? ' · último dia; D+15 pendente' : ''}` : card.delta != null ? 'Da primeira à fotografia mais recente' : card.missing;
      return `<article class="snapshot-summary-card ${available ? '' : 'unavailable'}" style="--snapshot-color:${card.color}"><span>${esc(card.label)}</span><strong class="${valueClass}">${value}</strong><small>${esc(detail)}</small></article>`;
    }).join('');

    const extraction = snapshotExtractionDate();
    $('snapshotHistoryTitle').textContent = `${processMeta().name} · ${state.snapshotScope} · ${selectionPeriodLabel(periods)}`;
    const series = [
      {key:'lastDay', label:'Último dia / mês atual parcial', color:'#6f747a'},
      ...(supportsD15 ? [{key:'d15', label:'Fechamento D+15', color:'#c3a400'}] : []),
      ...(supportsYtd ? [{key:'ytd', label:`YTD mais atual · ${extraction}`, color:processMeta().color, dash:'8 5'}] : [])
    ];
    $('snapshotHistoryLegend').innerHTML = series.map((item) => `<span class="snapshot-legend-item"><i style="--legend-color:${item.color}"></i>${esc(item.label)}</span>`).join('');

    let head = '<thead><tr><th>Mês de referência</th><th>Último dia / parcial</th>';
    if (supportsD15) head += '<th>Fechamento D+15</th>';
    if (supportsYtd) head += '<th>YTD mais atual</th>';
    if (supportsD15) head += '<th>Δ D+15 × último dia</th>';
    if (supportsD15 && supportsYtd) head += '<th>Δ YTD × D+15</th>';
    if (supportsYtd) head += '<th>Δ YTD × último dia</th>';
    head += '</tr></thead>';
    const body = comparisons.map((item) => {
      const deltaD15 = !item.d15?.provisional && item.lastDay?.metric != null && item.d15?.metric != null ? item.d15.metric - item.lastDay.metric : null;
      const deltaYtdD15 = !item.d15?.provisional && item.d15?.metric != null && item.ytd?.metric != null ? item.ytd.metric - item.d15.metric : null;
      const deltaYtdLast = !isCurrentPeriod(item.period) && item.lastDay?.metric != null && item.ytd?.metric != null ? item.ytd.metric - item.lastDay.metric : null;
      let cells = snapshotMetricCell(item.lastDay, isCurrentPeriod(item.period) ? 'Mês em andamento' : 'Base não encontrada');
      if (supportsD15) cells += snapshotMetricCell(item.d15, isCurrentPeriod(item.period) ? 'Ainda não aplicável' : 'Base não encontrada');
      if (supportsYtd) cells += snapshotMetricCell(item.ytd, 'Base YTD não encontrada');
      if (supportsD15) cells += snapshotDeltaCell(deltaD15, isCurrentPeriod(item.period) ? 'Ainda não aplicável' : (item.d15?.provisional ? 'D+15 pendente' : 'Sem par de bases'));
      if (supportsD15 && supportsYtd) cells += snapshotDeltaCell(deltaYtdD15, isCurrentPeriod(item.period) ? 'Ainda não aplicável' : (item.d15?.provisional ? 'D+15 pendente' : 'Sem par de bases'));
      if (supportsYtd) cells += snapshotDeltaCell(deltaYtdLast, isCurrentPeriod(item.period) ? 'Aguardando fechamento' : (item.d15?.provisional ? 'D+15 pendente' : 'Sem par de bases'));
      return `<tr class="${item.period === state.period ? 'current-period' : ''}"><td>${fmtPeriod(item.period)}<small>${isCurrentPeriod(item.period) ? 'mês em andamento' : 'mês encerrado'}</small></td>${cells}</tr>`;
    }).join('');
    $('snapshotHistoryTable').innerHTML = head + `<tbody>${body || '<tr><td colspan="7">Nenhum mês disponível.</td></tr>'}</tbody>`;
    drawSnapshotHistoryChart(comparisons, series);
  }

  function summaryMarkup(row, scope) {
    const delta = row.closing_delta;
    const deltaText = state.process === 'conectividade' ? 'D+15 não se aplica' : isCurrentPeriod(state.period) ? 'Mês atual em andamento' : delta == null ? 'Sem comparação entre fotografias' : `Variação D+15: ${fmtPp(delta)}`;
    let cells;
    if (state.process === 'dda') {
      const labels = {reception:'Recepção', preparation:'Preparação', delivery:'Entrega'};
      cells = Object.entries(labels).map(([key, label]) => {
        const component = row.components?.[key] || {};
        return `<div class="stat-cell"><span>${label}</span><strong class="metric ${component.band || 'neutral'}">${fmtPct(component.metric)}</strong><small>${fmtInt(component.numerator)} de ${fmtInt(component.denominator)}</small></div>`;
      });
      cells.push(`<div class="stat-cell"><span>Chassis</span><strong>${fmtInt(row.denominator)}</strong><small>volume elegível</small></div>`);
    } else {
      cells = processMeta().statuses.map((status) => {
        const count = row.components?.[status] || 0;
        const share = row.denominator ? count / row.denominator : null;
        return `<div class="stat-cell"><span>${esc(status)}</span><strong>${fmtInt(count)}</strong><small>${fmtPct(share)} do total</small></div>`;
      });
      cells.push(`<div class="stat-cell"><span>Total</span><strong>${fmtInt(row.denominator)}</strong><small>chassis avaliados</small></div>`);
    }
    return `<article class="hero-score"><div class="score-heading"><h3>${esc(scope)}</h3><span class="status-pill ${row.band}">${bandLabel(row.band)}</span></div><div class="score-value metric ${row.band}">${fmtPct(row.metric)}</div><div class="score-context"><span>${fmtPeriod(state.period)}</span><span>${snapshotLabel(state.snapshot, state.period)}</span><span>${deltaText}</span></div></article><article class="breakdown-card"><div class="breakdown-head"><h3>Composição do indicador</h3><span>${processMeta().target == null ? 'Sem objetivo definido' : `Objetivo ${fmtPct(processMeta().target)}`}</span></div><div class="breakdown-grid">${cells.join('')}</div></article>`;
  }

  function tableHead(nameLabel) {
    if (state.process === 'dda') return `<thead><tr><th>${nameLabel}</th><th>Rec. OK/Total</th><th>Recepção</th><th>Prep. OK/Total</th><th>Preparação</th><th>Ent. OK/Total</th><th>Entrega</th><th>DDA Total</th><th>Chassis</th></tr></thead>`;
    if (state.process === 'conectividade') return `<thead><tr><th>${nameLabel}</th><th>Pareado</th><th>Pareado depois</th><th>Total Pareado</th><th>Não pareado</th><th>Total chassis</th><th>Total Pareado (%)</th></tr></thead>`;
    const resultLabel = state.process === 'ltsm' ? 'Total Feito (%)' : state.process === 'battery_check' ? 'Total OK (%)' : 'Resultado';
    return `<thead><tr><th>${nameLabel}</th>${processMeta().statuses.map((status) => `<th>${esc(status)}</th>`).join('')}<th>Total</th><th>${resultLabel}</th></tr></thead>`;
  }

  function resultCells(row) {
    if (state.process === 'dda') {
      const components = row.components || {};
      const output = [];
      ['reception', 'preparation', 'delivery'].forEach((module) => {
        const item = components[module] || {};
        output.push({text:`${fmtInt(item.numerator)}/${fmtInt(item.denominator)}`});
        output.push({text:fmtPct(item.metric), metric:true, band:item.band || 'neutral'});
      });
      output.push({text:fmtPct(row.metric), metric:true, band:row.band});
      output.push({text:fmtInt(row.denominator)});
      return output;
    }
    if (state.process === 'conectividade') {
      const paired = firstComponentCount(row, ['Pareado', 'Conectado', 'Success']);
      const later = firstComponentCount(row, ['Pareado depois', 'Conectado depois', 'Paired later']);
      const notPaired = firstComponentCount(row, ['Não pareado', 'Não conectado']);
      return [
        {text:fmtInt(paired)},
        {text:fmtInt(later)},
        {text:fmtInt(paired + later)},
        {text:fmtInt(notPaired)},
        {text:fmtInt(row.denominator)},
        {text:fmtPct(row.metric), metric:true, band:row.band}
      ];
    }
    return [
      ...processMeta().statuses.map((status) => ({text:fmtInt(row.components?.[status] || 0)})),
      {text:fmtInt(row.denominator)},
      {text:fmtPct(row.metric), metric:true, band:row.band}
    ];
  }

  function resultRow(row, label, total = false) {
    return `<tr class="${total ? 'total' : ''}"><td>${esc(label)}</td>${resultCells(row).map((cell) => `<td class="${cell.metric ? `metric ${cell.band}` : ''}">${cell.text}</td>`).join('')}</tr>`;
  }

  function snapshotForPeriod(period) {
    return snapshotForSelectionPeriod(period);
  }

  function entityKey(row, level = state.entityLevel) {
    return level === 'Grupo' ? `${row.region}|${row.group || row.name}` : `${row.bir}`;
  }

  function entityName(row, level = state.entityLevel) {
    return level === 'Grupo' ? (row.group || row.name) : (row.dealer || row.name);
  }

  function timelineMetricDefinitions(process = state.process) {
    const definitions = {
      conectividade: [
        {key:'result', label:'Total Pareado'},
        {key:'paired', label:'Pareado'},
        {key:'paired_later', label:'Pareado depois'},
        {key:'not_paired', label:'Não pareado'}
      ],
      ltsm: [
        {key:'result', label:'On Time + Done Late'},
        {key:'on_time', label:'On Time'},
        {key:'done_late', label:'Done Late'},
        {key:'not_done', label:'Not Done'}
      ],
      battery_check: [
        {key:'result', label:'OK'},
        {key:'ko', label:'NOK'}
      ],
      dda: [
        {key:'result', label:'DDA Total'},
        {key:'reception', label:'Recepção'},
        {key:'preparation', label:'Preparação'},
        {key:'delivery', label:'Entrega'}
      ]
    };
    return definitions[process] || [{key:'result', label:'Resultado'}];
  }

  function componentMetric(row, key, process = state.process) {
    if (!row) return null;
    if (key === 'result') return row.metric;
    if (process === 'dda') return row.components?.[key]?.metric ?? null;
    const denominator = row.denominator || 0;
    if (!denominator) return null;
    const keyMap = {
      conectividade: {
        paired:['Pareado', 'Conectado', 'Success'],
        paired_later:['Pareado depois', 'Conectado depois', 'Paired later'],
        not_paired:['Não pareado', 'Não conectado']
      },
      ltsm: {on_time:['On Time'], done_late:['Done Late'], not_done:['Not Done']},
      battery_check: {ok:['OK', 'DIAG PREPA VN'], ko:['NOK', 'KO']}
    };
    const keys = keyMap[process]?.[key] || [];
    return keys.length ? firstComponentCount(row, keys) / denominator : null;
  }

  function componentTargetRule(process, key) {
    const meta = state.data.processes[process];
    if (!meta || meta.target == null) return null;
    if (process === 'dda') return {direction:'higher', target:meta.target, attention:meta.attention};
    if (key === 'result' || key === 'ok') return {direction:'higher', target:meta.target, attention:meta.attention};
    if ((process === 'conectividade' && key === 'not_paired') || (process === 'battery_check' && key === 'ko') || (process === 'ltsm' && key === 'not_done')) return {direction:'lower', target:1 - meta.target, attention:null};
    return null;
  }

  function metricBandForComponent(process, key, value) {
    if (value == null) return 'neutral';
    const rule = componentTargetRule(process, key);
    if (!rule) return 'neutral';
    if (rule.direction === 'lower') return value <= rule.target ? 'good' : 'bad';
    if (value >= rule.target) return 'good';
    if (rule.attention != null && value >= rule.attention) return 'attention';
    return 'bad';
  }

  function componentBand(row, key, process = state.process) {
    return metricBandForComponent(process, key, componentMetric(row, key, process));
  }

  function renderTimelineControls() {
    const definitions = timelineMetricDefinitions();
    const allowed = new Set(definitions.map((item) => item.key));
    state.timelineComponents = new Set([...state.timelineComponents].filter((key) => allowed.has(key)));
    if (!state.timelineComponents.size) state.timelineComponents.add('result');
    state.timelinePeriods = new Set(selectedProcessPeriods());
    const previousSort = $('timelineSort').value;
    $('timelineSort').innerHTML = definitions.map((item) => `<option value="metric:${item.key}">${esc(item.label)}</option>`).join('') + '<option value="evolution">Evolução no período</option><option value="volume">Volume selecionado</option>';
    $('timelineSort').value = [...$('timelineSort').options].some((option) => option.value === previousSort) ? previousSort : 'metric:result';
    $('timelineComponentChips').innerHTML = definitions.map((item) => `<button type="button" class="timeline-component-chip ${state.timelineComponents.has(item.key) ? 'active' : ''}" data-timeline-component="${item.key}">${esc(item.label)}</button>`).join('');
    qsa('[data-timeline-component]', $('timelineComponentChips')).forEach((button) => button.addEventListener('click', () => {
      const key = button.dataset.timelineComponent;
      if (state.timelineComponents.has(key)) {
        if (state.timelineComponents.size === 1) { toast('Mantenha ao menos um componente na linha do tempo.'); return; }
        state.timelineComponents.delete(key);
      } else state.timelineComponents.add(key);
      button.classList.toggle('active', state.timelineComponents.has(key));
      renderTimeline();
    }));
  }

  function accumulatedMetric(rows, key, process = state.process) {
    if (!rows.length) return null;
    if (process === 'dda') {
      const moduleMetric = (module) => {
        const numerator = rows.reduce((sum, row) => sum + (row.components?.[module]?.numerator || 0), 0);
        const denominator = rows.reduce((sum, row) => sum + (row.components?.[module]?.denominator || 0), 0);
        return denominator ? numerator / denominator : null;
      };
      if (key !== 'result') return moduleMetric(key);
      const values = ['reception','preparation','delivery'].map(moduleMetric);
      const available = values.filter((value) => value != null);
      return available.length ? available.reduce((sum, value) => sum + value, 0) / available.length : null;
    }
    const denominator = rows.reduce((sum, row) => sum + (row.denominator || 0), 0);
    if (!denominator) return null;
    if (key === 'result') return rows.reduce((sum, row) => sum + (row.numerator || 0), 0) / denominator;
    const numerator = rows.reduce((sum, row) => sum + (componentMetric(row, key, process) || 0) * (row.denominator || 0), 0);
    return numerator / denominator;
  }

  function renderTimeline() {
    if (!state.data) return;
    const periods = selectedProcessPeriods();
    const definitions = timelineMetricDefinitions();
    const displayed = definitions.filter((item) => state.timelineComponents.has(item.key));
    const sort = $('timelineSort').value || 'metric:result';
    const sortMetric = sort.startsWith('metric:') ? sort.split(':')[1] : 'result';
    const records = [];
    periods.forEach((period) => {
      const snapshot = snapshotForPeriod(period);
      metricRows().filter((row) => row.process === state.process && row.period === period && row.snapshot === snapshot && row.level === state.entityLevel && selectedRegions(row)).forEach((row) => records.push(row));
    });
    const entities = new Map();
    records.forEach((row) => {
      const key = entityKey(row);
      if (!entities.has(key)) entities.set(key, {key, name:entityName(row), region:row.region, group:row.group, bir:row.bir, rows:new Map()});
      entities.get(key).rows.set(row.period, row);
    });
    let items = [...entities.values()].map((item) => {
      const orderedRows = periods.map((period) => item.rows.get(period)).filter(Boolean);
      const values = orderedRows.map((row) => componentMetric(row, sortMetric)).filter((value) => value != null);
      const evolution = values.length > 1 ? values.at(-1) - values[0] : null;
      const accumulated = Object.fromEntries(displayed.map((definition) => [definition.key, accumulatedMetric(orderedRows, definition.key)]));
      return {...item, orderedRows, volume:orderedRows.reduce((sum, row) => sum + (row.denominator || 0), 0), evolution, accumulated, sortValue:accumulatedMetric(orderedRows, sortMetric)};
    });
    const query = $('timelineSearch').value.trim().toLocaleLowerCase('pt-BR');
    if (query) items = items.filter((item) => `${item.name} ${item.region} ${item.group || ''} ${item.bir || ''}`.toLocaleLowerCase('pt-BR').includes(query));
    const order = $('timelineOrder').value;
    const inverseMetric = sort.startsWith('metric:') && componentTargetRule(state.process, sortMetric)?.direction === 'lower';
    const compareNumber = (a, b) => {
      if (a == null && b == null) return 0;
      if (a == null) return 1;
      if (b == null) return -1;
      if (order === 'asc') return inverseMetric ? b - a : a - b;
      return inverseMetric ? a - b : b - a;
    };
    items.sort((a, b) => {
      if (order === 'alpha') return a.name.localeCompare(b.name, 'pt-BR');
      if (sort === 'evolution') return compareNumber(a.evolution, b.evolution) || a.name.localeCompare(b.name, 'pt-BR');
      if (sort === 'volume') return compareNumber(a.volume, b.volume) || a.name.localeCompare(b.name, 'pt-BR');
      return compareNumber(a.sortValue, b.sortValue) || a.name.localeCompare(b.name, 'pt-BR');
    });
    const sortLabel = definitions.find((item) => item.key === sortMetric)?.label || 'Resultado';
    $('timelinePeriodTitle').textContent = `${state.entityLevel} · ${processMeta().name} · ${periods.length} ${periods.length === 1 ? 'mês selecionado' : 'meses selecionados'} · ordenação por ${sortLabel}`;
    const monthGroups = periods.map((period) => `<th colspan="${displayed.length}" class="month-group ${period === state.period ? 'current-column' : ''}">${fmtMonthShort(period)}${isCurrentPeriod(period) ? ' · parcial' : ''}</th>`).join('');
    const monthComponents = periods.map((period) => displayed.map((definition, componentIndex) => `<th class="${period === state.period ? 'current-column ' : ''}${componentIndex === 0 ? 'period-start' : ''}">${esc(definition.label)}</th>`).join('')).join('');
    const accumulatedComponents = displayed.map((definition, componentIndex) => `<th class="accumulated-column ${componentIndex === 0 ? 'accumulated-start' : ''}">${esc(definition.label)}</th>`).join('');
    const head = `<thead><tr><th rowspan="2">#</th><th rowspan="2">${state.entityLevel}</th><th rowspan="2">Regional</th>${monthGroups}<th colspan="${displayed.length}" class="accumulated-group">Acumulado selecionado</th><th rowspan="2">Evolução<small>${esc(sortLabel)}</small></th><th rowspan="2">Volume selecionado</th></tr><tr>${monthComponents}${accumulatedComponents}</tr></thead>`;
    const body = items.map((item, index) => {
      const monthCells = periods.map((period) => displayed.map((definition, componentIndex) => {
        const row = item.rows.get(period);
        const value = componentMetric(row, definition.key);
        return `<td class="metric ${componentBand(row, definition.key)} ${period === state.period ? 'current-column ' : ''}${componentIndex === 0 ? 'period-start' : ''}">${value == null ? '–' : fmtPct(value)}</td>`;
      }).join('')).join('');
      const accumulatedCells = displayed.map((definition, componentIndex) => {
        const value = item.accumulated[definition.key];
        return `<td class="metric ${metricBandForComponent(state.process, definition.key, value)} accumulated-column ${componentIndex === 0 ? 'accumulated-start' : ''}">${value == null ? '–' : fmtPct(value)}</td>`;
      }).join('');
      return `<tr><td>${index + 1}</td><td title="${esc(item.name)}">${esc(item.name)}</td><td>${esc(item.region)}</td>${monthCells}${accumulatedCells}<td class="${deltaClass(item.evolution)}">${fmtPp(item.evolution)}</td><td>${fmtInt(item.volume)}</td></tr>`;
    }).join('');
    const columnCount = 5 + (periods.length + 1) * displayed.length;
    $('timelineTable').innerHTML = head + `<tbody>${body || `<tr><td colspan="${columnCount}">Nenhum grupo ou concessionária encontrado para os filtros informados.</td></tr>`}</tbody>`;
  }

  function deltaClass(value) {
    if (value == null || Math.abs(value) < .000001) return 'delta-flat';
    return value > 0 ? 'delta-up' : 'delta-down';
  }

  function renderTopFlop() {
    if (!state.data) return;
    const rows = groupCombinedRows(activeRows(state.entityLevel).filter(selectedRegions), state.entityLevel).filter((row) => row.metric != null);
    const top = rows.slice().sort((a, b) => b.metric - a.metric || b.denominator - a.denominator || a.name.localeCompare(b.name)).slice(0, 20);
    const flop = rows.slice().sort((a, b) => a.metric - b.metric || b.denominator - a.denominator || a.name.localeCompare(b.name)).slice(0, 20);
    const periodLabel = selectionPeriodLabel();
    $('topCardTitle').textContent = `${processMeta().name} · Top 20 ${state.entityLevel} · ${periodLabel}`;
    $('flopCardTitle').textContent = `${processMeta().name} · Flop 20 ${state.entityLevel} · ${periodLabel}`;
    $('topTable').innerHTML = rankingTable(top);
    $('flopTable').innerHTML = rankingTable(flop);
  }

  function rankingTable(rows) {
    const head = `<thead><tr><th>#</th><th>${state.entityLevel}</th><th>Regional</th><th>Volume</th><th>Resultado</th></tr></thead>`;
    const body = rows.map((row, index) => `<tr><td>${index + 1}</td><td>${esc(entityName(row))}</td><td>${esc(row.region)}</td><td>${fmtInt(row.denominator)}</td><td class="metric ${row.band}">${fmtPct(row.metric)}</td></tr>`).join('');
    return head + `<tbody>${body || '<tr><td colspan="5">Sem dados para os filtros selecionados.</td></tr>'}</tbody>`;
  }

  function selectedChassisKeys() {
    return selectedProcessPeriods().map((period) => `${state.process}|${period}|${snapshotForSelectionPeriod(period)}`);
  }

  function syntheticChassisRowsFor(period, snapshot) {
    const cacheKey = `${state.process}|${period}|${snapshot}`;
    if (state.chassisCache.has(cacheKey)) return state.chassisCache.get(cacheKey);
    if (Array.isArray(state.data.chassis)) {
      const provided = state.data.chassis.filter((row) => row.process === state.process && row.period === period && row.snapshot === snapshot);
      state.chassisCache.set(cacheKey, provided);
      return provided;
    }
    if (!state.data.demo_mode) return [];
    const models = ['KARDIAN','BOREAL','KWID','DUSTER','OROCH','KANGOO','KWID E-TECH'];
    const processCode = {conectividade:'C',ltsm:'L',battery_check:'B',dda:'D'}[state.process];
    const [year,month] = period.split('-').map(Number);
    const monthDays = new Date(year, month, 0).getDate();
    const rows = [];
    const dealerRows = metricRows().filter((row) => row.process === state.process && row.period === period && row.snapshot === snapshot && row.level === 'Concessionária');
    dealerRows.forEach((dealerRow, dealerOrder) => {
      const statuses = [];
      if (state.process === 'conectividade') {
        ['Pareado','Pareado depois','Não pareado'].forEach((status) => { for (let index=0; index<(dealerRow.components?.[status] || 0); index+=1) statuses.push({status,detail:status}); });
      } else if (state.process === 'ltsm') {
        ['On Time','Done Late','Not Done'].forEach((status) => { for (let index=0; index<(dealerRow.components?.[status] || 0); index+=1) statuses.push({status,detail:status}); });
      } else if (state.process === 'battery_check') {
        ['OK','NOK'].forEach((status) => { for (let index=0; index<(dealerRow.components?.[status] || 0); index+=1) statuses.push({status,detail:status}); });
      } else {
        for (let index=0; index<dealerRow.denominator; index+=1) {
          const moduleLabels = {reception:'Recepção',preparation:'Preparação',delivery:'Entrega'};
          const checks = Object.entries(moduleLabels).map(([key,label],moduleIndex) => {
            const score=((index*37+dealerOrder*13+moduleIndex*19)%100)/100;
            return {label,ok:score < (dealerRow.components?.[key]?.metric || 0)};
          });
          const completed=checks.filter((item)=>item.ok).length;
          statuses.push({status:completed===3?'Completo':completed===0?'Não realizado':'Parcial',detail:checks.map((item)=>`${item.label}: ${item.ok?'OK':'NOK'}`).join(' · '), ...Object.fromEntries(Object.keys(moduleLabels).flatMap((key, i)=>[[`${key}_den`,1],[`${key}_num`,Number(checks[i].ok)]]))});
        }
      }
      statuses.slice(0,dealerRow.denominator).forEach((item,index) => {
        const day=String(1+((index*7+dealerOrder*3)%monthDays)).padStart(2,'0');
        const vin=`93Y${processCode}${period.replace('-','').slice(2)}${String(dealerRow.bir).slice(-4)}${String(index+1).padStart(5,'0')}`;
        rows.push({process:state.process,period,snapshot,vin,date:`${period}-${day}`,status:item.status,detail:item.detail,model:state.model || models[(index+dealerOrder)%models.length],...Object.fromEntries(Object.entries(item).filter(([key])=>key.endsWith('_num')||key.endsWith('_den'))),region:dealerRow.region,group:dealerRow.group,dealer:dealerRow.dealer,bir:dealerRow.bir});
      });
    });
    state.chassisCache.set(cacheKey,rows);
    return rows;
  }

  function syntheticChassisRows() {
    return selectedProcessPeriods().flatMap((period) => syntheticChassisRowsFor(period, snapshotForSelectionPeriod(period)));
  }

  function chassisStatusBand(status) {
    if (['Pareado','Pareado depois','On Time','Done Late','OK','Completo'].includes(status)) return 'good';
    if (['Parcial'].includes(status)) return 'attention';
    return 'bad';
  }

  function clearChassisFilters(shouldRender=true) {
    ['chassisStatus','chassisDateFrom','chassisDateTo','chassisRegion','chassisGroup','chassisDealer','chassisVin'].forEach((id) => { if ($(id)) $(id).value=''; });
    if (shouldRender) renderChassis();
  }

  const chassisColumns = ['vin','date','status','detail','model','region','group','dealer','bir'];
  async function loadGithubChassis(key) {
    if (state.chassisCache.has(key)) return state.chassisCache.get(key);
    if (state.chassisPending.has(key)) return state.chassisPending.get(key);
    const task = (async () => {
      if (!state.chassisManifest) {
        const response = await fetch('./data/chassis/manifest.json');
        if (!response.ok) throw new Error('Não foi possível carregar o manifesto de chassis.');
        state.chassisManifest = await response.json();
      }
      const entry = state.chassisManifest.datasets[key];
      if (!entry) return [];
      const [process,period,snapshot] = key.split('|');
      const rows=[];
      for (const part of entry.parts) {
        let response;
        try {
          response=await fetch(part.url);
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
        } catch (error) { console.error('Falha ao carregar arquivo de chassis:',part.url,error); throw error; }
        const packed=await response.json();
        const cols=packed.columns || chassisColumns;
        for (const line of packed.rows) {
          const row={process,period,snapshot};
          cols.forEach((column,index)=>row[column]=packed.dictionaries?.[column] ? packed.dictionaries[column][line[index]] : line[index]);
          rows.push(row);
        }
      }
      if (rows.length !== entry.count) throw new Error(`Quantidade de chassis inconsistente: ${key}`);
      state.chassisCache.set(key,rows);
      return rows;
    })();
    state.chassisPending.set(key,task);
    try { return await task; } finally { state.chassisPending.delete(key); }
  }

  function ddaModuleView(row) {
    const module = state.ddaChassisModule;
    const numerator = Number(row[`${module}_num`] || 0);
    const denominator = Number(row[`${module}_den`] || 0);
    if (!numerator && !denominator) return null;
    const label = {preparation:'Preparação', delivery:'Entrega', reception:'Recepção'}[module];
    return {...row,
      status: denominator === 0 ? 'Sem evento global' : numerator ? 'OK' : 'NOK',
      detail: `${label}: ${numerator}/${denominator} ocorrências (realizadas / globais)`};
  }

  async function renderChassis() {
    const request=++state.chassisRequest;
    if (!state.data || !$('chassisTable') || state.view !== 'chassis') return;
    const keys=selectedChassisKeys();
    const selectionSignature=keys.join('||');
    if (document.body.dataset.mode === 'group-report' && !state.data?.chassis_available) {
      $('chassisVisibleCount').textContent = '0';
      $('chassisNote').textContent = 'Os chassis não foram incluídos nesta exportação de grupo. Ative a opção “Incluir chassis” ao gerar o ZIP.';
      $('chassisTable').innerHTML = '';
      return;
    }
    if (document.body.dataset.mode === 'github-pages') {
      if (!state.data?.chassis_available) {
        $('chassisVisibleCount').textContent='0';
        $('chassisNote').textContent='Os dados de chassis não foram incluídos nesta publicação.';
        $('chassisTable').innerHTML='';
        return;
      }
      const missing=keys.filter((key)=>!state.chassisCache.has(key));
      if (missing.length) {
        $('chassisNote').textContent=`Carregando chassis de ${processMeta().name} · ${selectionPeriodLabel()}...`;
        $('chassisTable').innerHTML='';
        try { await Promise.all(missing.map((key)=>loadGithubChassis(key))); }
        catch(error) {
          if(request !== state.chassisRequest || state.view !== 'chassis') return;
          console.error('Falha ao carregar chassis:',error);
          $('chassisNote').textContent='Os chassis não puderam ser carregados.';
          $('chassisTable').innerHTML='<tbody><tr><td><button type="button" id="retryChassis">Tentar novamente</button></td></tr></tbody>';
          $('retryChassis').addEventListener('click',()=>renderChassis());
          return;
        }
      }
      if(request !== state.chassisRequest || state.view !== 'chassis' || selectionSignature !== selectedChassisKeys().join('||')) return;
    }

    $('ddaChassisModules').hidden = state.process !== 'dda';
    const allRows = syntheticChassisRows().filter((row) => !state.model || normalizedModelName(row.model) === normalizedModelName(state.model));
    const rows = state.process === 'dda' ? allRows.map(ddaModuleView).filter(Boolean) : allRows;
    const previousStatus=$('chassisStatus').value, previousRegion=$('chassisRegion').value;
    const statuses=[...new Set(rows.map((row)=>row.status))].sort((a,b)=>a.localeCompare(b,'pt-BR'));
    $('chassisStatus').innerHTML='<option value="">Todos</option>'+statuses.map((status)=>`<option value="${esc(status)}">${esc(status)}</option>`).join('');
    $('chassisStatus').value=statuses.includes(previousStatus)?previousStatus:'';
    $('chassisRegion').innerHTML='<option value="">Todas</option>'+state.data.regions.map((region)=>`<option value="${region}">${region}</option>`).join('');
    $('chassisRegion').value=state.data.regions.includes(previousRegion)?previousRegion:'';
    const normalize=(value)=>String(value||'').toLocaleLowerCase('pt-BR');
    const status=$('chassisStatus').value, from=$('chassisDateFrom').value, to=$('chassisDateTo').value, region=$('chassisRegion').value;
    const group=normalize($('chassisGroup').value), dealer=normalize($('chassisDealer').value), vin=normalize($('chassisVin').value);
    const filtered=rows.filter((row)=>(!status||row.status===status)&&(!from||row.date>=from)&&(!to||row.date<=to)&&(!region||row.region===region)&&(!group||normalize(row.group).includes(group))&&(!dealer||normalize(`${row.dealer} ${row.bir}`).includes(dealer))&&(!vin||normalize(row.vin).includes(vin)));
    $('chassisVisibleCount').textContent=fmtInt(filtered.length);
    const sourceNote = state.data.demo_mode ? 'Nesta demonstração, os registros são artificiais.' : 'Registros carregados das bases do processo.';
    const photo = state.snapshot === 'ytd_atual' ? 'YTD mais atual' : selectedProcessPeriods().length === 1 ? snapshotLabel(snapshotForSelectionPeriod(state.period),state.period) : 'fotografia aplicada por mês';
    $('chassisNote').textContent=`${processMeta().name} · ${selectionPeriodLabel()} · ${photo} · ${state.process === 'dda' ? {preparation:'Preparação',delivery:'Entrega',reception:'Recepção'}[state.ddaChassisModule] + ' · ' : ''}${fmtInt(filtered.length)} de ${fmtInt(rows.length)} chassis. ${sourceNote}`;
    const head='<thead><tr><th>Chassi</th><th>Data</th><th>Status</th><th>Detalhe</th><th>Modelo</th><th>Grupo</th><th>Concessionária</th><th>BIR</th><th>Regional</th></tr></thead>';
    const body=filtered.map((row)=>`<tr><td>${esc(row.vin)}</td><td>${new Date(`${row.date}T12:00:00`).toLocaleDateString('pt-BR')}</td><td><span class="status-pill ${chassisStatusBand(row.status)}">${esc(row.status)}</span></td><td>${esc(row.detail||'–')}</td><td>${esc(row.model||'–')}</td><td>${esc(row.group)}</td><td>${esc(row.dealer)}</td><td>${esc(row.bir)}</td><td>${esc(row.region)}</td></tr>`).join('');
    $('chassisTable').innerHTML=head+`<tbody>${body||'<tr><td colspan="9">Nenhum chassi corresponde aos filtros selecionados.</td></tr>'}</tbody>`;
  }

  function availableEntities() {
    const rows = metricRows().filter((row) => row.process === state.process && row.level === state.entityLevel);
    const map = new Map();
    if (isGroupReport) {
      const info = state.data.group_report;
      if (state.entityLevel === 'Grupo') {
        const key = `${info.region}|${info.group}`;
        map.set(key, {key, level:'Grupo', name:info.group, region:info.region, group:info.group, bir:'', dealer:''});
      } else {
        (info.dealers || []).forEach(item => {
          const key = String(item.bir);
          map.set(key, {key, level:'Concessionária', name:item.dealer, region:info.region, group:info.group, bir:item.bir, dealer:item.dealer});
        });
      }
    }
    rows.forEach((row) => {
      const key = entityKey(row);
      if (!map.has(key)) map.set(key, {key, level:state.entityLevel, name:entityName(row), region:row.region, group:row.group, bir:row.bir, dealer:row.dealer});
    });
    return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
  }

  function renderSearch() {
    if (!state.data) return;
    const isGroup = state.entityLevel === 'Grupo';
    $('searchLabel').textContent = isGroup ? 'Nome do grupo' : 'Nome, BIR ou grupo';
    $('entitySearch').placeholder = isGroup ? 'Digite o nome do grupo' : 'Digite concessionária, BIR ou grupo';
    const query = $('entitySearch').value.trim().toLocaleLowerCase('pt-BR');
    const entities = availableEntities();
    const filtered = query ? entities.filter((entity) => `${entity.name} ${entity.group || ''} ${entity.bir || ''}`.toLocaleLowerCase('pt-BR').includes(query)).slice(0, 40) : [];
    $('searchResults').innerHTML = filtered.map((entity) => `<button type="button" class="result-button ${state.selectedEntity?.key === entity.key ? 'selected' : ''}" data-entity-key="${esc(entity.key)}"><strong>${esc(entity.name)}</strong><span>${esc(isGroup ? entity.region : `${entity.bir} · ${entity.group} · ${entity.region}`)}</span></button>`).join('');
    qsa('[data-entity-key]', $('searchResults')).forEach((button) => button.addEventListener('click', () => {
      state.selectedEntity = entities.find((entity) => entity.key === button.dataset.entityKey) || null;
      renderSearch();
    }));
    if (state.selectedEntity) renderEntityDetail();
    else {
      $('entityDetail').className = 'detail-panel empty-state';
      $('entityDetail').textContent = `Pesquise e selecione ${isGroup ? 'um grupo' : 'uma concessionária'} para abrir o detalhamento.`;
    }
  }

  function historyRowsForEntity(entity, periods = selectedProcessPeriods(), snapshotMode = 'selected') {
    if (!entity) return [];
    return periods.map((period) => {
      const snapshot = snapshotMode === 'ytd' ? 'ytd_atual' : snapshotForPeriod(period);
      return metricRows().find((row) => {
        if (row.process !== state.process || row.period !== period || row.snapshot !== snapshot || row.level !== entity.level) return false;
        return entity.level === 'Grupo' ? row.region === entity.region && row.group === entity.group : row.bir === entity.bir;
      }) || null;
    }).filter(Boolean);
  }

  function ytdRowsForEntity(entity) {
    if (!entity || !ytdProcesses.has(state.process)) return [];
    const periods = new Set(selectedProcessPeriods());
    return metricRows().filter((row) => {
      if (row.process !== state.process || row.snapshot !== 'ytd_atual' || row.level !== entity.level || !periods.has(row.period)) return false;
      return entity.level === 'Grupo' ? row.region === entity.region && row.group === entity.group : row.bir === entity.bir;
    }).sort((a,b)=>a.period.localeCompare(b.period));
  }

  function renderEntityDetail() {
    const entity = state.selectedEntity;
    const rows = historyRowsForEntity(entity);
    const selectedAggregate = combine(rows, state.process);
    const ytdRows = ytdRowsForEntity(entity);
    const accumulatedRows = ytdProcesses.has(state.process) ? ytdRows : rows;
    const accumulated = combine(accumulatedRows, state.process);
    const detail = $('entityDetail');
    detail.className = 'detail-panel';
    const accumulatedLabel = ytdProcesses.has(state.process) ? 'YTD mais atual' : 'Acumulado dos meses selecionados';
    const showClosingComparison = state.process !== 'conectividade';
    const tableRows = rows.map((row) => {
      const closingCell = showClosingComparison ? `<td class="${isCurrentPeriod(row.period) ? 'delta-flat' : deltaClass(row.closing_delta)}">${isCurrentPeriod(row.period) ? 'Em andamento' : fmtPp(row.closing_delta)}</td>` : '';
      return `<tr><td>${fmtPeriod(row.period)}</td><td>${snapshotShort(row.snapshot, row.period)}</td><td>${fmtInt(row.denominator)}</td><td class="metric ${row.band}">${fmtPct(row.metric)}</td>${closingCell}</tr>`;
    }).join('');
    const scorePeriod = selectionPeriodLabel();
    const accumulatedContext = ytdProcesses.has(state.process)
      ? `${accumulatedRows.length} ${accumulatedRows.length === 1 ? 'mês selecionado' : 'meses selecionados'} · base YTD mais atual`
      : `${rows.length} ${rows.length === 1 ? 'mês selecionado' : 'meses selecionados'}`;
    detail.innerHTML = `<div class="entity-detail-grid"><aside class="detail-summary"><p class="eyebrow">${esc(entity.region)}${entity.level === 'Concessionária' ? ` · ${esc(entity.group)}` : ''}</p><h3>${esc(entity.name)}</h3>${entity.bir ? `<p class="muted">BIR ${esc(entity.bir)}</p>` : ''}${selectedAggregate ? `<div class="score-value metric ${selectedAggregate.band}">${fmtPct(selectedAggregate.metric)}</div><span class="status-pill ${selectedAggregate.band}">${bandLabel(selectedAggregate.band)}</span><p class="muted">${fmtInt(selectedAggregate.denominator)} chassis · ${esc(scorePeriod)}</p>` : '<p>Sem resultado neste processo.</p>'}<div class="accumulated">${accumulated ? `<strong>${accumulatedLabel}: ${fmtPct(accumulated.metric)}</strong>${fmtInt(accumulated.denominator)} chassis · ${esc(accumulatedContext)}` : `Sem ${ytdProcesses.has(state.process) ? 'base YTD' : 'dados'} para o período.`}</div></aside><div><div id="entityChart" class="chart"></div><div class="table-wrap"><table><thead><tr><th>Mês</th><th>Fotografia</th><th>Volume</th><th>Resultado</th>${showClosingComparison ? '<th>Comparação de fechamento</th>' : ''}</tr></thead><tbody>${tableRows || `<tr><td colspan="${showClosingComparison ? 5 : 4}">Sem dados nos meses selecionados.</td></tr>`}</tbody></table></div></div></div>`;
    drawChart('entityChart', rows, processMeta().target, processMeta().color);
  }

  function drawChart(id, rows, target, color) {
    const element = $(id);
    if (!element) return;
    if (!rows.length) { element.innerHTML = '<div class="empty-state">Sem histórico disponível.</div>'; return; }
    const width = 900, height = 255, padding = {left:48, right:20, top:24, bottom:40};
    const x = (index) => padding.left + (rows.length === 1 ? (width - padding.left - padding.right) / 2 : index * (width - padding.left - padding.right) / (rows.length - 1));
    const y = (value) => padding.top + (1 - Math.max(0, Math.min(1, value ?? 0))) * (height - padding.top - padding.bottom);
    let grid = '';
    [0, .25, .5, .75, 1].forEach((value) => { grid += `<line class="grid" x1="${padding.left}" x2="${width - padding.right}" y1="${y(value)}" y2="${y(value)}"/><text x="${padding.left - 8}" y="${y(value) + 4}" text-anchor="end">${value * 100}%</text>`; });
    const points = rows.map((row, index) => `${x(index)},${y(row.metric)}`).join(' ');
    const targetLine = target == null ? '' : `<line x1="${padding.left}" x2="${width - padding.right}" y1="${y(target)}" y2="${y(target)}" stroke="#111" stroke-dasharray="6 5"/><text x="${width - padding.right}" y="${y(target) - 7}" text-anchor="end">Meta ${fmtPct(target)}</text>`;
    element.innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Linha do tempo mensal">${grid}${targetLine}<polyline class="line" style="stroke:${color}" points="${points}"/>${rows.map((row, index) => `<circle class="dot" style="fill:${color}" cx="${x(index)}" cy="${y(row.metric)}" r="5"/><text x="${x(index)}" y="${height - 12}" text-anchor="middle">${fmtPeriod(row.period)}</text><text x="${x(index)}" y="${y(row.metric) - 10}" text-anchor="middle">${fmtPct(row.metric)}</text>`).join('')}</svg>`;
  }

  function openDiagnostics() {
    const dialog = $('diagnosticsDialog');
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  }

  function renderDiagnostics() {
    const issues = state.data.diagnostics || [];
    const levels = ['critical', 'warning', 'information'];
    $('diagnosticSummary').innerHTML = levels.map((level) => `<div class="diagnostic-card ${level}"><strong>${issues.filter((item) => item.level === level).length}</strong><span>${level === 'critical' ? 'Erros críticos' : level === 'warning' ? 'Avisos' : 'Informações'}</span></div>`).join('');
    $('diagnosticTable').innerHTML = '<thead><tr><th>Nível</th><th>Processo</th><th>Arquivo</th><th>Problema</th><th>Quantidade</th><th>Consequência</th><th>Ação recomendada</th></tr></thead><tbody>' + (issues.map((item) => `<tr><td>${esc(item.level)}</td><td>${esc(item.process)}</td><td>${esc(item.file)}</td><td>${esc(item.message)}</td><td>${fmtInt(item.count)}</td><td>${esc(item.consequence)}</td><td>${esc(item.action)}</td></tr>`).join('') || '<tr><td colspan="7">Nenhuma ocorrência.</td></tr>') + '</tbody>';
    const dates = state.data.date_diagnostics || [];
    $('dateDiagnosticTable').innerHTML = '<thead><tr><th>Processo</th><th>Arquivo</th><th>Coluna</th><th>Linhas</th><th>Válidas</th><th>Em branco</th><th>Inválidas</th><th>Aviso de formato</th><th>Exemplos para conferir</th></tr></thead><tbody>' + (dates.map((item) => `<tr><td>${esc(item.process)}</td><td>${esc(item.file)}</td><td>${esc(item.column)}</td><td>${fmtInt(item.total)}</td><td>${fmtInt(item.valid)}</td><td>${fmtInt(item.blank)}</td><td>${fmtInt(item.invalid)}</td><td>${item.format_warning ? 'Sim' : 'Não'}</td><td>${esc((item.examples?.length ? item.examples : item.formats_examples || []).join(' · '))}</td></tr>`).join('') || '<tr><td colspan="9">Nenhum arquivo com datas analisado.</td></tr>') + '</tbody>';
    const columns = state.data.column_diagnostics || [];
    $('columnDiagnosticTable').innerHTML = '<thead><tr><th>Fonte</th><th>Campo</th><th>Coluna encontrada</th><th>Letra</th><th>Método</th><th>Status</th><th>Motivo</th></tr></thead><tbody>' + columns.map((item) => `<tr><td>${esc(item.source)}</td><td>${esc(item.label)}</td><td>${esc(item.column)}</td><td>${esc(item.letter)}</td><td>${esc(item.method)}</td><td>${esc(item.status)}</td><td>${esc(item.reason)}</td></tr>`).join('') + '</tbody>';
  }

  async function reloadBases() {
    const promise = fetch('/api/reload', {method:'POST'}).then((response) => response.json());
    pollProgress(promise);
    const result = await promise;
    if (!result.ok) { setProgress(false); toast(result.error || 'Falha ao recarregar.'); return; }
    window.INLINE_PAYLOAD = null;
    state.data = await fetch('/api/dashboard').then((response) => response.json());
    setProgress(false);
    state.selectedEntity = null;
    state.chassisCache.clear();
    renderModelFilter();
    updateProcessControls();
    renderDiagnostics();
    toast('Bases recarregadas.');
  }

  async function exportHtml(mode) {
    const include_chassis = mode === 'groups' ? Boolean($('includeGroupChassis')?.checked) : Boolean($('includeChassis')?.checked);
    if (mode === 'groups') {
      const warning = include_chassis
        ? 'O ZIP administrativo conterá VINs nos relatórios individuais de cada grupo. O acesso a esses arquivos deve ser restrito ao grupo autorizado. NÃO publique o pacote nem seu manifesto no GitHub Pages ou em site público. Deseja continuar?'
        : 'Será gerado um ZIP administrativo com relatórios por grupo, sem VINs. NÃO publique o pacote ou seu manifesto em site público. Deseja continuar?';
      if (!window.confirm(warning)) return;
    }
    if (mode === 'github-pages' && include_chassis && !window.confirm('Esta exportação incluirá VINs em arquivos estáticos. Qualquer pessoa com acesso ao site poderá baixar esses dados. Deseja continuar?')) return;
    const promise = fetch(`/api/export/${mode}`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({include_chassis})}).then((response) => response.json());
    pollProgress(promise);
    const result = await promise;
    setProgress(false);
    if (!result.ok) { toast(result.error || 'Falha na exportação.'); return; }
    const link = document.createElement('a');
    link.href = result.url;
    link.download = '';
    document.body.appendChild(link);
    link.click();
    link.remove();
    toast(mode === 'groups' ? 'Relatórios individuais por grupo gerados.' : mode === 'github-pages' ? 'ZIP GitHub Pages gerado.' : 'HTML gerado.');
  }

  async function copyBlockAsPng(id) {
    const source = $(id);
    if (!source) return;
    try {
      const wrappers = qsa('.table-wrap', source);
      const extraHeight = wrappers.reduce((sum, wrapper) => sum + Math.max(0, wrapper.scrollHeight - wrapper.clientHeight), 0);
      const fullWidth = wrappers.reduce((maximum, wrapper) => Math.max(maximum, wrapper.scrollWidth), 0);
      const clone = source.cloneNode(true);
      qsa('.copy-image', clone).forEach((button) => button.remove());
      qsa('.table-wrap', clone).forEach((wrapper) => { wrapper.style.maxHeight = 'none'; wrapper.style.overflow = 'visible'; wrapper.style.width = 'max-content'; wrapper.style.minWidth = '100%'; });
      const width = Math.max(source.scrollWidth, fullWidth + 40, 900);
      const height = Math.max(source.scrollHeight + extraHeight, 150);
      clone.style.cssText += `;width:${width}px;max-height:none;overflow:visible;background:#fff;padding:20px`;
      const styles = [...document.styleSheets].map((sheet) => { try { return [...sheet.cssRules].map((rule) => rule.cssText).join(''); } catch (error) { return ''; } }).join('');
      const markup = new XMLSerializer().serializeToString(clone);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml"><style>${styles}</style>${markup}</div></foreignObject></svg>`;
      const blob = new Blob([svg], {type:'image/svg+xml'});
      const url = URL.createObjectURL(blob);
      const image = new Image();
      await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = url; });
      const canvas = document.createElement('canvas');
      canvas.width = width * 2;
      canvas.height = height * 2;
      const context = canvas.getContext('2d');
      context.scale(2, 2);
      context.drawImage(image, 0, 0);
      URL.revokeObjectURL(url);
      const png = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
      if (navigator.clipboard && window.ClipboardItem) {
        await navigator.clipboard.write([new ClipboardItem({'image/png':png})]);
        toast('Imagem copiada.');
      } else {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(png);
        link.download = 'resultado.png';
        link.click();
        toast('Imagem baixada.');
      }
    } catch (error) {
      toast('O navegador bloqueou a cópia. Use a captura de tela do sistema.');
    }
  }

  if (document.body.dataset.mode !== 'server') qsa('.server-only').forEach((element) => element.remove());
  // O HTML exportado carrega os dados incorporados e não precisa bloquear a tela.
  // Alguns visualizadores do iOS limitam ou interrompem JavaScript em arquivos locais;
  // por isso a camada começa oculta e também recebe uma saída de segurança.
  const embeddedProgressFailsafe = document.body.dataset.embedded === 'true'
    ? setTimeout(() => setProgress(false), 1500)
    : null;
  Promise.resolve(loadData())
    .catch((error) => {
      setProgress(false);
      console.error('Falha ao inicializar o dashboard:', error);
      const banner=document.createElement('div');
      banner.setAttribute('role','alert');
      banner.style.cssText='margin:18px;padding:20px;background:#fff5d1;border:2px solid #d19b00;border-radius:9px;color:#171717';
      banner.textContent=error.message || 'Não foi possível abrir o dashboard.';
      document.querySelector('.wrap')?.prepend(banner);
    })
    .finally(() => {
      if (embeddedProgressFailsafe) clearTimeout(embeddedProgressFailsafe);
    });
})();
